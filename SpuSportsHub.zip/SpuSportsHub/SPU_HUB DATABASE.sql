drop database SPUSportsHub;

-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS SPUSportsHub;

-- Use the database
USE SPUSportsHub;

-- Create the Users table
CREATE TABLE IF NOT EXISTS Users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Optional: Insert a sample user (for testing purposes)
-- INSERT INTO Users (username, password) VALUES ('testuser', PASSWORD('testpassword'));
select*from Users;