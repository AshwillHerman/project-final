-- -----------------------------------------------------
-- Schema SPUSportsHub
-- -----------------------------------------------------
DROP DATABASE IF EXISTS SPUSportsHub ;
CREATE DATABASE IF NOT EXISTS SPUSportsHub;
USE SPUSportsHub ;

-- -----------------------------------------------------
-- Table `Users`
-- -----------------------------------------------------

DROP TABLE IF EXISTS Users;

-- Users table (existing table with email column added)

CREATE TABLE IF NOT EXISTS Users (
  user_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  student_number VARCHAR(255) UNIQUE,  -- Make student_number nullable
  staff_number VARCHAR(255) UNIQUE,    -- Make staff_number nullable
  full_name VARCHAR(255) NOT NULL, 
  password VARCHAR(255) NOT NULL, 
  phone VARCHAR(255) NULL, 
  registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
  is_admin TINYINT UNSIGNED NOT NULL DEFAULT 0, 
  profile_picture VARCHAR(255) NULL DEFAULT 'default_profile.jpg',
  email VARCHAR(255) NOT NULL UNIQUE,  -- Add email column for password reset
  PRIMARY KEY (user_id)
) ENGINE = InnoDB; -- Use InnoDB storage engine for better performance and reliability
ALTER TABLE Users
ADD CONSTRAINT at_least_one_id 
CHECK (student_number IS NOT NULL OR staff_number IS NOT NULL);

-- Password Resets table (new table)
DROP TABLE IF EXISTS password_resets;

CREATE TABLE IF NOT EXISTS password_resets (
  email VARCHAR(255) NOT NULL,
  token VARCHAR(255) NOT NULL UNIQUE,
  expiry_date DATETIME NOT NULL,
  PRIMARY KEY (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4; 

-- -----------------------------------------------------
-- Table `Sports`
-- -----------------------------------------------------
DROP TABLE IF EXISTS Sports ;

CREATE TABLE IF NOT EXISTS Sports(
  sport_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  sport_name VARCHAR(255) NOT NULL UNIQUE,
  description TEXT NULL,
  image_url VARCHAR(255) NULL DEFAULT 'default_sport.jpg', -- URL/path
  PRIMARY KEY (sport_id))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Teams`
-- -----------------------------------------------------
DROP TABLE IF EXISTS Teams ;

CREATE TABLE IF NOT EXISTS Teams (
  team_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  sport_id INT UNSIGNED NOT NULL,
  team_name VARCHAR(255) NOT NULL,
  gender ENUM('Male', 'Female', 'Mixed') NOT NULL, -- Include 'Mixed' option
  team_level ENUM('1st', '2nd', '3rd', 'Junior') NOT NULL, -- More descriptive
  coach_name VARCHAR(255) NULL,
  achievements TEXT NULL,
  image_url VARCHAR(255) NULL DEFAULT 'default_team.jpg', -- URL/path
  PRIMARY KEY (team_id),
  CONSTRAINT fk_Teams_Sports1
    FOREIGN KEY (sport_id)
    REFERENCES Sports (sport_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TeamMembers`
-- -----------------------------------------------------
DROP TABLE IF EXISTS TeamMembers ;

CREATE TABLE IF NOT EXISTS TeamMembers (
  member_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  team_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NULL, -- Allow NULL if not a registered user on the platform
  full_name VARCHAR(255) NOT NULL, 
  role VARCHAR(255) NOT NULL,
  PRIMARY KEY (member_id),
  CONSTRAINT fk_TeamMembers_Teams1
    FOREIGN KEY (team_id)
    REFERENCES Teams (team_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_TeamMembers_Users1
    FOREIGN KEY (user_id)
    REFERENCES Users (user_id)
    ON DELETE SET NULL 
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Players`
-- -----------------------------------------------------
DROP TABLE IF EXISTS Players ;

CREATE TABLE IF NOT EXISTS Players (
  player_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  member_id INT UNSIGNED NOT NULL,
  position VARCHAR(255) NULL,
  statistics JSON NULL, -- Use JSON for flexible stats storage
  PRIMARY KEY (player_id),
  CONSTRAINT fk_Players_TeamMembers1
    FOREIGN KEY (member_id)
    REFERENCES TeamMembers (member_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `Events` 
-- -----------------------------------------------------
DROP TABLE IF EXISTS Events ;

CREATE TABLE IF NOT EXISTS Events (
  event_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  sport_id INT UNSIGNED NOT NULL, 
  home_team_id INT UNSIGNED NULL, -- Can be NULL for general sports events
  away_team_id INT UNSIGNED NULL, -- Can be NULL for general sports events 
  event_date DATETIME NOT NULL,
  venue VARCHAR(255) NOT NULL,
  score_home INT NULL DEFAULT 0, 
  score_away INT NULL DEFAULT 0, 
  is_live TINYINT UNSIGNED DEFAULT 0, -- Add "is_live" flag (0 for false, 1 for true)
  result_details TEXT NULL,       -- For additional details about the event outcome 
  PRIMARY KEY (event_id),
  CONSTRAINT fk_Events_Sports1
    FOREIGN KEY (sport_id)
    REFERENCES Sports (sport_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_Events_Teams1
    FOREIGN KEY (home_team_id)
    REFERENCES Teams (team_id)
    ON DELETE SET NULL
    ON UPDATE CASCADE,
  CONSTRAINT fk_Events_Teams2
    FOREIGN KEY (away_team_id)
    REFERENCES Teams (team_id)
    ON DELETE SET NULL
    ON UPDATE CASCADE)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `Products`
-- -----------------------------------------------------
DROP TABLE IF EXISTS Products ;

CREATE TABLE IF NOT EXISTS Products (
  product_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  product_name VARCHAR(255) NOT NULL,
  description TEXT NULL,
  category ENUM('clothing', 'accessories', 'equipment') NOT NULL,
  price DECIMAL(10,2) UNSIGNED NOT NULL,
  image_url VARCHAR(255) NULL DEFAULT 'default_product.jpg', -- URL/path (Make sure this column exists)
  stock_quantity INT UNSIGNED NOT NULL,
  PRIMARY KEY (product_id))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Orders`
-- -----------------------------------------------------
DROP TABLE IF EXISTS Orders ;

CREATE TABLE IF NOT EXISTS Orders (
  order_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  total_amount DECIMAL(10,2) UNSIGNED NOT NULL,
  status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') NOT NULL,
  shipping_address VARCHAR(255) NOT NULL, 
  payment_method VARCHAR(255) NOT NULL,
  PRIMARY KEY (order_id),
  CONSTRAINT fk_Orders_Users1
    FOREIGN KEY (user_id)
    REFERENCES Users (user_id)
    ON DELETE NO ACTION 
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `OrderItems` 
-- -----------------------------------------------------
DROP TABLE IF EXISTS OrderItems ;

CREATE TABLE IF NOT EXISTS OrderItems (
  order_item_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  order_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  quantity INT UNSIGNED NOT NULL, 
  PRIMARY KEY (order_item_id),
  CONSTRAINT fk_OrderItems_Orders1
    FOREIGN KEY (order_id)
    REFERENCES Orders (order_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_OrderItems_Products1
    FOREIGN KEY (product_id)
    REFERENCES Products (product_id)
    ON DELETE NO ACTION -- Usually no deletion from this table
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ForumCategories`
-- -----------------------------------------------------
DROP TABLE IF EXISTS ForumCategories ;

CREATE TABLE IF NOT EXISTS ForumCategories (
  category_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_name VARCHAR(255) NOT NULL,
  description TEXT NULL,
  PRIMARY KEY (category_id))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ForumPosts`
-- -----------------------------------------------------
DROP TABLE IF EXISTS ForumPosts ;

CREATE TABLE IF NOT EXISTS ForumPosts (
  post_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (post_id),
  CONSTRAINT fk_ForumPosts_ForumCategories1
    FOREIGN KEY (category_id)
    REFERENCES ForumCategories (category_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_ForumPosts_Users1
    FOREIGN KEY (user_id)
    REFERENCES Users (user_id)
    ON DELETE CASCADE -- Delete posts if user is deleted
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Comments` 
-- -----------------------------------------------------
DROP TABLE IF EXISTS Comments ;

CREATE TABLE IF NOT EXISTS Comments (
  comment_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  post_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (comment_id),
  CONSTRAINT fk_Comments_ForumPosts1
    FOREIGN KEY (post_id)
    REFERENCES ForumPosts (post_id)
    ON DELETE CASCADE -- Delete comments if post is deleted
    ON UPDATE CASCADE,
  CONSTRAINT fk_Comments_Users1
    FOREIGN KEY (user_id)
    REFERENCES Users (user_id)
    ON DELETE CASCADE 
    ON UPDATE CASCADE)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `News`
-- -----------------------------------------------------
DROP TABLE IF EXISTS News ;

CREATE TABLE IF NOT EXISTS News (
  news_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  image_url VARCHAR(255) NULL, -- URL to the news image
  author VARCHAR(255) NULL,   -- Add author column
  status ENUM('Draft', 'Published', 'Archived') NOT NULL DEFAULT 'Draft', -- Add status column with default
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP, -- Track updates
  PRIMARY KEY (news_id))
ENGINE = InnoDB; 

-- -----------------------------------------------------
-- Table `Likes` -- Tracks likes on both Posts AND Comments
-- -----------------------------------------------------
DROP TABLE IF EXISTS Likes ;

CREATE TABLE IF NOT EXISTS Likes (
  like_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  post_id INT UNSIGNED NULL,
  comment_id INT UNSIGNED NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (like_id),
  CONSTRAINT fk_Likes_Users1
    FOREIGN KEY (user_id)
    REFERENCES Users (user_id)
    ON DELETE CASCADE 
    ON UPDATE CASCADE,
  CONSTRAINT fk_Likes_ForumPosts1
    FOREIGN KEY (post_id)
    REFERENCES ForumPosts (post_id)
    ON DELETE CASCADE 
    ON UPDATE CASCADE,
  CONSTRAINT fk_Likes_Comments1
    FOREIGN KEY (comment_id)
    REFERENCES Comments (comment_id)
    ON DELETE CASCADE 
    ON UPDATE CASCADE)
ENGINE = InnoDB;


select * from Users;

-- Insert sports into the Sports table based on your provided HTML

INSERT INTO Sports (sport_name, description, image_url) VALUES
('Netball', 'Develop your netball skills and compete at the highest level with SPU.', '/images/netball.jpg'),
('Football (Male)', 'Join our competitive football teams and showcase your skills on the field.', '/images/football.jpg'),
('Football (Female)', 'Join our competitive football teams and showcase your skills on the field.', '/images/football-f.jpg'),
('Golf', 'Improve your swing and compete on the greens with our golf program.', '/images/golf.jpg'),
('Hockey', 'Experience the fast-paced action of hockey with our dedicated teams.', '/images/hockey.jpg'),
('Aerobics/Dance Sport', 'Combine fitness and artistry with our aerobics and dance sport programs.', '/images/aerobics.jpg'),
('Volleyball', 'Develop teamwork and spike your way to victory with our volleyball teams.', '/images/volleyball.jpg'),
('Chess', 'Challenge your mind and compete in strategic battles with our chess team.', '/images/chess.jpg'),
('Karate', 'Learn self-defense and discipline through our karate program.', '/images/karate.jpg'),
('Rugby', 'Be part of our strong rugby tradition and represent SPU on the pitch.', '/images/rugby.jpg'),
('Cheerleading', 'Show your spirit and support our teams with our cheerleading squad.', '/images/cheerleading.jpg'),
('Basketball', 'Experience the thrill of fast-paced basketball action with our talented teams.', '/images/basketball.jpg'),
('Tennis', 'Improve your serve and volley with our tennis program.', '/images/tennis.jpg'),
('Table Tennis', 'Develop your reflexes and precision with our table tennis team.', '/images/tabletennis.jpg'),
('Cricket', 'Join our cricket team and experience the excitement of the game.', '/images/cricket.jpg'),
('Athletics', 'Push your limits in various track and field events with our athletics program.', '/images/athletics.jpeg'); 

-- You can verify the data was inserted correctly:
SELECT * FROM Sports; 