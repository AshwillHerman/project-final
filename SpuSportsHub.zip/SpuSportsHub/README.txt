install composer
install phpmailer

composer require phpmailer/phpmailer                                                                                                                                                                                   

