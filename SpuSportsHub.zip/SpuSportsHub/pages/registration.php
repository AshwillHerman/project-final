<?php
/**
 * registration.php: Handles user registration and login for the 
 * Sol Plaatje University Sports Hub.
 */

// Start the session to manage user login status
session_start();

// Database connection details (you should store these securely)
$servername = "127.0.0.1"; 
$username = "root";         
$password = "Kd0783820098"; 
$dbname = "SPUSportsHub";    

// Create a connection to the database
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

/**
 * Sanitizes user inputs to prevent security vulnerabilities like XSS.
 *
 * @param string $data The input data to sanitize.
 * @return string The sanitized data.
 */
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Handles user login for both students and admins.
 *
 * @param mysqli $conn The database connection.
 * @return string|null Error message if login fails, null otherwise.
 */
function handleLogin($conn) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Determine if it's a student or admin login based on the form submitted
        $isAdminLogin = isset($_POST['staff-number']);

        // Sanitize user inputs
        $username = sanitizeInput($isAdminLogin ? $_POST["staff-number"] : $_POST["student-number"]);
        $password = sanitizeInput($isAdminLogin ? $_POST["password"] : $_POST["password"]);

        // Prepare and execute the SQL query based on login type
        if ($isAdminLogin) {
            $sql = "SELECT * FROM Users WHERE staff_number=? AND is_admin=1";
        } else {
            $sql = "SELECT * FROM Users WHERE student_number=?";
        }

        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) {
            die("Error preparing login query: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        // Check if a user was found
        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);
            // Verify the password
            if (password_verify($password, $row["password"])) {
                // Set session variables to indicate the user is logged in
                $_SESSION["loggedin"] = true;
                $_SESSION["user_id"] = $row["user_id"];
                $_SESSION["username"] = $isAdminLogin ? $row["staff_number"] : $row["student_number"];
                $_SESSION["is_admin"] = $row["is_admin"];

                // Redirect based on user type
                if ($row["is_admin"]) {
                    header("Location: admin.php"); 
                } else {
                    header("Location: profile.php"); 
                }
                exit;
            } else {
                return "Incorrect password.";
            }
        } else {
            return "Invalid username or password."; 
        }
        mysqli_stmt_close($stmt);
    }
    return null; 
}

/**
 * Handles user registration for students.
 *
 * @param mysqli $conn The database connection.
 * @return string|null Error or success message, or null if no action taken.
 */
function handleStudentRegistration($conn) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Sanitize user inputs
        $studentNumber = sanitizeInput($_POST["student-number"]);
        $fullName = sanitizeInput($_POST["full-name"]);
        $email = sanitizeInput($_POST["email"]);
        $password = sanitizeInput($_POST["password"]);
        $confirmPassword = sanitizeInput($_POST["confirm-password"]);

        // Basic form validation
        if ($password != $confirmPassword) {
            return "Passwords do not match.";
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return "Invalid email format.";
        }
        
         // Check if student number or email already exists
        $checkSql = "SELECT * FROM Users WHERE student_number = ? OR email = ?";
        $checkStmt = mysqli_prepare($conn, $checkSql);
        mysqli_stmt_bind_param($checkStmt, "ss", $studentNumber, $email);
        mysqli_stmt_execute($checkStmt);
        $checkResult = mysqli_stmt_get_result($checkStmt);
    
        if (mysqli_num_rows($checkResult) > 0) {
            return "Student number or email already exists.";
        }
    

        // Handle file upload (if a file was selected)
        $profilePicture = 'default_profile.jpg'; 
        if (isset($_FILES['profile-picture']) && $_FILES['profile-picture']['error'] === UPLOAD_ERR_OK) {
            $targetDir = "uploads/"; 
            $targetFile = $targetDir . basename($_FILES["profile-picture"]["name"]);
            $imageFileType = strtolower(pathinfo($targetFile,PATHINFO_EXTENSION));

            // Check if image file is valid
            $check = getimagesize($_FILES["profile-picture"]["tmp_name"]);
            if($check === false) {
                return "File is not an image.";
            } 

            // Check if file already exists
            if (file_exists($targetFile)) {
                return "Sorry, file already exists.";
            }

            // Check file size
            if ($_FILES["profile-picture"]["size"] > 2000000) { 
                return "Sorry, your file is too large.";
            }

            // Allow certain file formats
            $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
            if(!in_array($imageFileType, $allowedTypes)) {
                return "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            }

            // Try to upload the file
            if (!move_uploaded_file($_FILES["profile-picture"]["tmp_name"], $targetFile)) {
                return "Sorry, there was an error uploading your file.";
            } else {
                $profilePicture = basename($_FILES["profile-picture"]["name"]);
            }
        }

        // Hash the password for security
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Insert the new user into the database
        $sql = "INSERT INTO Users (student_number, full_name, email, password, profile_picture, is_admin) VALUES (?, ?, ?, ?, ?, 0)";
        $stmt = mysqli_prepare($conn, $sql); 

        if (!$stmt) {
            die("Error preparing registration query: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "sssss", $studentNumber, $fullName, $email, $hashedPassword, $profilePicture);

        if (mysqli_stmt_execute($stmt)) {
            $_SESSION["loggedin"] = true;
            $_SESSION["user_id"] = mysqli_insert_id($conn); 
            $_SESSION["username"] = $studentNumber;
            $_SESSION["is_admin"] = 0; 
            header("Location: profile.php"); 
            exit; 
        } else {
            return "Error during registration: " . mysqli_error($conn);
        }

        mysqli_stmt_close($stmt);
    }
    return null;
}

/**
 * Handles admin registration.
 *
 * @param mysqli $conn The database connection.
 * @return string|null Error or success message, or null if no action taken.
 */
function handleAdminRegistration($conn) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Sanitize user inputs
        $staffNumber = sanitizeInput($_POST["staff-number"]);
        $fullName = sanitizeInput($_POST["full-name"]);
        $email = sanitizeInput($_POST["email"]);
        $password = sanitizeInput($_POST["password"]);
        $confirmPassword = sanitizeInput($_POST["confirm-password"]);

        // Basic form validation
        if ($password != $confirmPassword) {
            return "Passwords do not match.";
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return "Invalid email format.";
        }
        
        // Check if staff number or email already exists
        $checkSql = "SELECT * FROM Users WHERE staff_number = ? OR email = ?";
        $checkStmt = mysqli_prepare($conn, $checkSql);
        mysqli_stmt_bind_param($checkStmt, "ss", $staffNumber, $email);
        mysqli_stmt_execute($checkStmt);
        $checkResult = mysqli_stmt_get_result($checkStmt);
    
        if (mysqli_num_rows($checkResult) > 0) {
            return "Staff number or email already exists.";
        }
        

        // Hash the password for security
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Insert the new admin into the database 
        $sql = "INSERT INTO Users (staff_number, full_name, email, password, is_admin) VALUES (?, ?, ?, ?, 1)"; 
        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {
            die("Error preparing registration query: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "ssss", $staffNumber, $fullName, $email, $hashedPassword);

        if (mysqli_stmt_execute($stmt)) {
            $_SESSION["loggedin"] = true;
            $_SESSION["user_id"] = mysqli_insert_id($conn); 
            $_SESSION["username"] = $staffNumber; 
            $_SESSION["is_admin"] = 1;
            header("Location: admin.php"); 
            exit; 
        } else {
            return "Error during admin registration: " . mysqli_error($conn); 
        }

        mysqli_stmt_close($stmt);
    }
    return null; 
}

// Handle login 
$loginError = handleLogin($conn);

// Handle registrations based on form submission
if (isset($_POST['student-number']) && isset($_POST['full-name']) && 
    isset($_POST['password']) && isset($_POST['confirm-password'])) {

    if (isset($_POST['staff-number'])) {
        $adminRegistrationMessage = handleAdminRegistration($conn);
    } else {
        $studentRegistrationMessage = handleStudentRegistration($conn);
    }
}

// Determine which tab should be active
$activeTab = 'login';
if (isset($_GET['tab']) && in_array($_GET['tab'], ['login', 'student-register', 'admin-register', 'admin'])) {
    $activeTab = $_GET['tab'];
} elseif (isset($_POST['student-number']) && isset($_POST['password'])) {
    $activeTab = isset($_POST['staff-number']) ? 'admin' : 'login';
} elseif (isset($_POST['student-number']) && isset($_POST['full-name']) && isset($_POST['password']) && isset($_POST['confirm-password'])) {
    $activeTab = isset($_POST['staff-number']) ? 'admin-register' : 'student-register';
}

// Dynamic page title, meta description, and site name
$pageTitle = "Login/Register | Sol Plaatje University Sports Hub";
$metaDescription = "Sol Plaatje University Sports Hub - Login or register to access personalized features and connect with the SPU sports community.";
$siteName = "Sol Plaatje University Sports Hub"; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $pageTitle; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $metaDescription; ?>">

    <!-- 3rd Party Links -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Roboto:wght@400;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" href="/images/favicon.ico" type="image/x-icon"> 

    <!-- Custom Stylesheets -->
    <link rel="stylesheet" href="/styles/registration.css">
</head>
<body>

    <?php include 'header.php'; ?> 

    <main class="main-content">
        <section class="auth-section">
            <div class="auth-container">
                <!-- Tabs for Login/Registration -->
                <div class="auth-tabs">
                    <button class="auth-tab <?php echo $activeTab == 'login' ? 'active' : ''; ?>" data-tab="login">Login</button>
                    <button class="auth-tab <?php echo $activeTab == 'student-register' ? 'active' : ''; ?>" data-tab="student-register">Student Register</button>
                    <button class="auth-tab <?php echo $activeTab == 'admin-register' ? 'active' : ''; ?>" data-tab="admin-register">Admin Register</button>
                    <button class="auth-tab <?php echo $activeTab == 'admin' ? 'active' : ''; ?>" data-tab="admin">Admin Login</button>
                </div>

                <!-- Student Login Form -->
                <form id="login-form" class="auth-form <?php echo $activeTab == 'login' ? 'active' : ''; ?>" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                    <h2>Student Login</h2>

                    <?php if (isset($loginError)): ?>
                        <div class="error-message"><?php echo $loginError; ?></div>
                    <?php endif; ?>

                    <div class="input-group">
                        <label for="student-number"><i class="fas fa-id-card"></i> Student Number:</label>
                        <input type="text" id="student-number" name="student-number" required>
                    </div>

                    <div class="input-group">
                        <label for="password"><i class="fas fa-lock"></i> Password:</label>
                        <input type="password" id="password" name="password" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Login</button>

                    <div class="auth-footer">
                        <a href="/pages/forgot_password.php" class="forgot-password"><i class="fas fa-question-circle"></i> Forgot Password?</a>
                    </div>
                </form>

                <!-- Student Registration Form -->
                <form id="student-register-form" class="auth-form <?php echo $activeTab == 'student-register' ? 'active' : ''; ?>" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data"> 
                    <h2>Register for <?php echo $siteName; ?> (Student)</h2>

                    <?php if (isset($studentRegistrationMessage)): ?>
                        <div class="<?php echo isset($error) ? 'error-message' : 'success-message'; ?>">
                            <?php echo $studentRegistrationMessage; ?>
                        </div>
                    <?php endif; ?>

                    <div class="input-group">
                        <label for="student-number"><i class="fas fa-id-card"></i> Student Number:</label>
                        <input type="text" id="student-number" name="student-number" required>
                    </div>

                    <div class="input-group">
                        <label for="full-name"><i class="fas fa-user"></i> Full Name:</label>
                        <input type="text" id="full-name" name="full-name" required>
                    </div>

                    <div class="input-group">
                        <label for="email"><i class="fas fa-envelope"></i> Email:</label>
                        <input type="email" id="email" name="email" required>
                    </div>

                    <div class="input-group">
                        <label for="password"><i class="fas fa-lock"></i> Password:</label>
                        <input type="password" id="password" name="password" required>
                    </div>

                    <div class="input-group">
                        <label for="confirm-password"><i class="fas fa-lock"></i> Confirm Password:</label>
                        <input type="password" id="confirm-password" name="confirm-password" required>
                    </div>

                    <div class="input-group">
                        <label for="profile-picture"><i class="fas fa-image"></i> Profile Picture (Optional):</label>
                        <input type="file" id="profile-picture" name="profile-picture">
                    </div>

                    <div class="checkbox-container">
                        <input type="checkbox" id="terms-agree" name="terms-agree" required>
                        <label for="terms-agree">I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>.</label>
                    </div>

                    <button type="submit" class="btn btn-primary">Register</button>
                </form>

                <!-- Admin Registration Form -->
                <form id="admin-register-form" class="auth-form <?php echo $activeTab == 'admin-register' ? 'active' : ''; ?>" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">
                    <h2>Register for <?php echo $siteName; ?> (Admin)</h2>

                    <?php if (isset($adminRegistrationMessage)): ?>
                        <div class="<?php echo isset($error) ? 'error-message' : 'success-message'; ?>">
                            <?php echo $adminRegistrationMessage; ?>
                        </div>
                    <?php endif; ?>

                    <div class="input-group">
                        <label for="staff-number"><i class="fas fa-id-badge"></i> Staff Number:</label>
                        <input type="text" id="staff-number" name="staff-number" required> 
                    </div>

                    <div class="input-group">
                        <label for="full-name"><i class="fas fa-user"></i> Full Name:</label>
                        <input type="text" id="full-name" name="full-name" required>
                    </div>

                    <div class="input-group">
                        <label for="email"><i class="fas fa-envelope"></i> Email:</label>
                        <input type="email" id="email" name="email" required>
                    </div>

                    <div class="input-group">
                        <label for="password"><i class="fas fa-lock"></i> Password:</label>
                        <input type="password" id="password" name="password" required>
                    </div>

                    <div class="input-group">
                        <label for="confirm-password"><i class="fas fa-lock"></i> Confirm Password:</label>
                        <input type="password" id="confirm-password" name="confirm-password" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Register</button>
                </form>

                <!-- Admin Login Form -->
                <form id="admin-form" class="auth-form <?php echo $activeTab == 'admin' ? 'active' : ''; ?>" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                    <h2>Admin Login</h2>

                    <?php if (isset($loginError)): ?>
                        <div class="error-message"><?php echo $loginError; ?></div>
                    <?php endif; ?>

                    <div class="input-group">
                        <label for="staff-number"><i class="fas fa-id-badge"></i> Staff Number:</label>
                        <input type="text" id="staff-number" name="staff-number" required>
                    </div>

                    <div class="input-group">
                        <label for="admin-password"><i class="fas fa-lock"></i> Password:</label>
                        <input type="password" id="password" name="password" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Login</button>
                </form>
            </div>
        </section>
    </main>

    <?php include 'footer.php'; ?>

    <script src="/scripts/registration.js"></script> 
</body>
</html>