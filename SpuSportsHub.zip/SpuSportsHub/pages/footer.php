<!-- Footer Section -->
<footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <img src="/images/logo.png" alt="SPU Logo" class="footer-logo">
                    <p>SPU Sport contributes to the development and overall wellbeing of students by embracing diversity and providing students with the necessary opportunities and resources.</p>
                    <div class="social-icons">
                        <a href="https://www.facebook.com/SolPlaatjeUniv/" aria-label="Facebook"><i class="fab fa-facebook"></i></a>
                        <a href="https://x.com/MySPU?mx=2" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.instagram.com/sol_plaatje_university/" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                        <a href="https://www.linkedin.com/company/sol-plaatje-university/" aria-label="LinkedIn"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
                <div class="footer-section">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="/pages/home.php">Home</a></li>
                        <li><a href="/pages/sports.html">Sports</a></li>
                        <li><a href="/pages/schedules&Results.html">Schedules & Results</a></li>
                        <li><a href="/pages/shop.html">Shop</a></li>
                        <li><a href="/pages/community.html">Community</a></li>
                        <li><a href="/pages/aboutUs.php">About Us</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contact Us</h3>
                    <p><i class="fas fa-map-marker-alt"></i> Chapel Street, Kimberley, 8301</p>
                    <p><i class="fas fa-phone"></i> +27 (0)53 491 0000</p>
                    <p><i class="fas fa-envelope"></i> info@spu.ac.za</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>© 2023 Sol Plaatje University Sports Hub. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="/scripts/home.js"></script>
</body>
</html>