<?php

/**
 * Profile Management Page
 * 
 * This page allows users to manage their profile information, including:
 * - Account details (name, email, phone)
 * - Order history
 * - Forum activity (posts and comments)
 * - Preferences (favorite sports and teams)
 * - Security (password change)
 * - Profile picture
 * - Account deletion
 */

// Start the session
session_start();

// Database connection details
$servername = "127.0.0.1";
$username = "root";
$password = "Kd0783820098";
$dbname = "SPUSportsHub"; 

// Create a connection to the database
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("Location: /pages/registration.php"); // Redirect to login page
    exit;
}

// Get user ID from session
$user_id = $_SESSION["user_id"];

// Function to sanitize user inputs (prevent XSS)
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Fetch user data from the database
$sql = "SELECT * FROM Users WHERE user_id = '$user_id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 1) {
    $userData = mysqli_fetch_assoc($result);
    // Decode JSON preferences if they exist (handle potential errors)
    $userData['favorite_sports'] = isset($userData['favorite_sports']) ? json_decode($userData['favorite_sports'], true) : [];
    $userData['favorite_teams'] = isset($userData['favorite_teams']) ? json_decode($userData['favorite_teams'], true) : [];
} else {
    die("Error fetching user data: " . mysqli_error($conn));
}

// Initialize error and success messages
$accountError = $accountSuccess = $passwordError = $passwordSuccess = $pictureError = $pictureSuccess = $deleteError = $preferencesError = $preferencesSuccess = "";

// Flags for confirmation modals
$showDeleteConfirmation = false; 

// Handle form submissions (Account Info, Preferences, Security, Change Picture, Delete Account)
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // **Account Info Update**
    if (isset($_POST["update-account"])) {
        $fullName = sanitizeInput($_POST["full-name"]);
        $email = sanitizeInput($_POST["email"]);
        $phone = sanitizeInput($_POST["phone"]);

        // Input validation (add more validation as needed)
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $accountError = "Invalid email format";
        } else {
            // Update the database
            $sql = "UPDATE Users SET full_name='$fullName', email='$email', phone='$phone' WHERE user_id='$user_id'";

            if (mysqli_query($conn, $sql)) {
                $accountSuccess = "Account information updated successfully!";
                // Update $userData so the displayed data is immediately updated
                $userData['full_name'] = $fullName;
                $userData['email'] = $email;
                $userData['phone'] = $phone;
            } else {
                $accountError = "Error updating account information: " . mysqli_error($conn);
            }
        }
    }

    // **Preferences Update**
    if (isset($_POST["update-preferences"])) {
        $favoriteSports = isset($_POST["favorite-sports"]) ? $_POST["favorite-sports"] : [];
        $favoriteTeams = isset($_POST["favorite-teams"]) ? $_POST["favorite-teams"] : [];

        // Convert arrays to JSON strings
        $favoriteSportsJson = json_encode($favoriteSports);
        $favoriteTeamsJson = json_encode($favoriteTeams);

        // Update the database with JSON data
        $sql = "UPDATE Users SET 
                favorite_sports = '$favoriteSportsJson', 
                favorite_teams = '$favoriteTeamsJson' 
                WHERE user_id = '$user_id'";

        if (mysqli_query($conn, $sql)) {
            $preferencesSuccess = "Preferences updated successfully!";
            // Update $userData so the displayed data is immediately updated
            $userData['favorite_sports'] = $favoriteSports; // Store the array, not the JSON
            $userData['favorite_teams'] = $favoriteTeams; // Store the array, not the JSON 
        } else {
            $preferencesError = "Error updating preferences: " . mysqli_error($conn);
        }
    }

    // **Security (Password Change)**
    if (isset($_POST["change-password"])) {
        $currentPassword = sanitizeInput($_POST["current-password"]);
        $newPassword = sanitizeInput($_POST["new-password"]);
        $confirmPassword = sanitizeInput($_POST["confirm-password"]);

        // Verify current password
        if (!password_verify($currentPassword, $userData['password'])) {
            $passwordError = "Incorrect current password.";
        } elseif ($newPassword !== $confirmPassword) {
            $passwordError = "New passwords do not match.";
        } else {
            // Hash the new password
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

            // Update the password in the database
            $sql = "UPDATE Users SET password = '$hashedPassword' WHERE user_id = '$user_id'";
            if (mysqli_query($conn, $sql)) {
                $passwordSuccess = "Password changed successfully!";
            } else {
                $passwordError = "Error changing password: " . mysqli_error($conn);
            }
        }
    }

    // **Change Profile Picture**
    if (isset($_FILES['profile-picture']) && $_FILES['profile-picture']['error'] === UPLOAD_ERR_OK) {
        $targetDir = "uploads/";
        $targetFile = $targetDir . basename($_FILES["profile-picture"]["name"]);
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Check if image file is valid
        $check = getimagesize($_FILES["profile-picture"]["tmp_name"]);
        if ($check !== false) {
            // Allow certain file formats
            if ($imageFileType == "jpg" || $imageFileType == "png" || $imageFileType == "jpeg" || $imageFileType == "gif") {
                // If no errors, try to upload the file
                if (move_uploaded_file($_FILES["profile-picture"]["tmp_name"], $targetFile)) {
                    $newProfilePicture = basename($_FILES["profile-picture"]["name"]);

                    // Update database with the new picture name
                    $sql = "UPDATE Users SET profile_picture = '$newProfilePicture' WHERE user_id = '$user_id'";
                    if (mysqli_query($conn, $sql)) {
                        $pictureSuccess = "Profile picture updated successfully!";
                        $userData['profile_picture'] = $newProfilePicture; // Update $userData
                    } else {
                        $pictureError = "Error updating profile picture in database: " . mysqli_error($conn);
                    }
                } else {
                    $pictureError = "Sorry, there was an error uploading your file.";
                }
            } else {
                $pictureError = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            }
        } else {
            $pictureError = "File is not an image.";
        }
    }

    // **Delete Account (Initial Request - Show Confirmation)**
    if (isset($_POST["delete-account"])) {
        // Set the flag to show the delete confirmation modal
        $showDeleteConfirmation = true; 
    }

    // **Confirm Delete Account**
    if (isset($_POST["confirm-delete-account"])) {
        // Delete the user from the Users table
        $sql = "DELETE FROM Users WHERE user_id = '$user_id'"; 

        if (mysqli_query($conn, $sql)) {
            // Log the user out and redirect to the home page 
            session_destroy();
            header("Location: /pages/home.html"); 
            exit;
        } else {
            $deleteError = "Error deleting account: " . mysqli_error($conn);
        }
    }
}

// Fetch Order History
$sql = "SELECT o.order_id, o.order_date, o.total_amount, o.status 
        FROM Orders o
        WHERE o.user_id = '$user_id'";
$orderHistoryResult = mysqli_query($conn, $sql);
$orderHistoryData = [];
while ($row = mysqli_fetch_assoc($orderHistoryResult)) {
    $orderHistoryData[] = $row;
}

// Fetch Forum Activity (My Posts and My Comments)
// Fetching posts from a 'ForumPosts' table 
$sql = "SELECT * FROM ForumPosts WHERE user_id = '$user_id'";
$postsResult = mysqli_query($conn, $sql);
$postsData = [];
while ($row = mysqli_fetch_assoc($postsResult)) {
    $postsData[] = $row;
} 

// Fetching comments from a 'Comments' table
$sql = "SELECT * FROM Comments WHERE user_id = '$user_id'";
$commentsResult = mysqli_query($conn, $sql);
$commentsData = [];
while ($row = mysqli_fetch_assoc($commentsResult)) {
    $commentsData[] = $row;
}


// Fetch Sports and Teams for Preferences
$sql = "SELECT sport_id, sport_name FROM Sports";
$sportsResult = mysqli_query($conn, $sql);
$sportsData = [];
while ($row = mysqli_fetch_assoc($sportsResult)) {
    $sportsData[] = $row;
}

$sql = "SELECT team_id, team_name FROM Teams";
$teamsResult = mysqli_query($conn, $sql);
$teamsData = [];
while ($row = mysqli_fetch_assoc($teamsResult)) {
    $teamsData[] = $row;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Profile Management | Sol Plaatje University Sports Hub</title>
    <link rel="stylesheet" href="/styles/profile.css">
</head>


<body>

<?php include 'header.php'; ?>


    <main class="profile-section" role="main">
        <div class="p-container">
            <h1 id="my-profile" class="profile-title">My Profile</h1>

            <div class="profile-container">
                <div class="profile-sidebar">
                    <div class="profile-picture">
                        <img src="uploads/<?php echo $userData['profile_picture']; ?>" alt="Profile Picture">
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data" class="profile-picture-form">
                            <div class="file-upload-wrapper">
                                <input type="file" class="file-upload-input" name="profile-picture" id="profile-picture-input" accept="image/*" hidden>
                                <label for="profile-picture-input" class="file-upload-label">
                                    <span class="upload-icon"><i class="fa fa-camera"></i></span>
                                    <span class="upload-text">Choose a new picture</span>
                                </label>
                            </div>
                            <button type="submit" class="btn btn-primary upload-btn">Update Profile Picture</button>
                        </form>
                        <?php if (!empty($pictureError)): ?> 
                            <div class="error-message"><?php echo $pictureError; ?></div>
                        <?php endif; ?>
                        <?php if (!empty($pictureSuccess)): ?>
                            <div class="success-message"><?php echo $pictureSuccess; ?></div>
                        <?php endif; ?>
                    </div>
                    <nav class="profile-nav">
                        <ul>
                            <li><a href="#account-info" class="active">Account Information</a></li>
                            <li><a href="#order-history">Order History</a></li>
                            <li><a href="#forum-activity">Forum Activity</a></li>
                            <li><a href="#preferences">Preferences</a></li>
                            <li><a href="#security">Security</a></li>
                            <li><a href="#delete-account">Delete Account</a></li>
                        </ul>
                    </nav>
                </div>

                <div class="profile-content">
                    <section id="account-info" class="profile-section active">
                        <h2>Account Information</h2>
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                            <div class="form-group">
                                <label for="full-name">Full Name</label>
                                <input type="text" id="full-name" name="full-name" value="<?php echo $userData['full_name']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email" value="<?php echo $userData['email']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone</label>
                                <input type="tel" id="phone" name="phone" value="<?php echo $userData['phone']; ?>">
                            </div>
                            <div class="form-group">
                                <label for="student-id">Student ID</label>
                                <input type="text" id="student-id" name="student-id" value="<?php echo isset($userData['student_number']) ? $userData['student_number'] : (isset($userData['staff_number']) ? $userData['staff_number'] : ''); ?>" readonly>
                            </div>
                            <button type="submit" class="btn btn-primary" name="update-account">Save Changes</button>
                        </form>
                        <?php if (!empty($accountError)): ?>
                            <div class="error-message"><?php echo $accountError; ?></div>
                        <?php endif; ?>
                        <?php if (!empty($accountSuccess)): ?>
                            <div class="success-message"><?php echo $accountSuccess; ?></div>
                        <?php endif; ?>
                    </section>

                    <section id="order-history" class="profile-section">
                        <h2>Order History</h2>
                        <?php if (empty($orderHistoryData)): ?>
                            <div class="empty-state">
                                <i class="fas fa-shopping-cart fa-3x"></i> 
                                <p>You haven't made any orders yet.</p>
                                <a href="/pages/shop.html" class="btn btn-secondary">Start Shopping</a>
                            </div>
                        <?php else: ?>
                            <table class="order-table">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Date</th>
                                        <th>Total Amount</th>
                                        <th>Status</th>
                                        <th>Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($orderHistoryData as $order): ?>
                                        <tr>
                                            <td><?php echo $order['order_id']; ?></td>
                                            <td><?php echo $order['order_date']; ?></td>
                                            <td>R<?php echo $order['total_amount']; ?></td>
                                            <td><?php echo $order['status']; ?></td>
                                            <td>
                                                <a href="/pages/order_details.php?order_id=<?php echo $order['order_id']; ?>"> 
                                                    View Details
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </section>

                    <section id="forum-activity" class="profile-section">
                        <h2>Forum Activity</h2>
                        <div class="forum-tabs">
                            <button class="active" data-tab="my-posts">My Posts</button>
                            <button data-tab="my-comments">My Comments</button>
                        </div>
                        <div id="my-posts" class="forum-section active">
                            <!-- My Posts Content -->
                            <?php 
                             if (!empty($postsData)) {
                                foreach ($postsData as $post) {
                                    echo "<div><h3>" . $post['title'] . "</h3><p>" . $post['content'] . "</p></div>"; 
                                }
                             } else {
                                echo "<p>You haven't created any posts yet.</p>";
                             }
                            ?> 
                        </div>
                        <div id="my-comments" class="forum-section">
                            <!-- My Comments Content -->
                            <?php 
                             if (!empty($commentsData)) {
                                foreach ($commentsData as $comment) {
                                    echo "<div><p>" . $comment['content'] . "</p></div>"; 
                                }
                             } else {
                                echo "<p>You haven't made any comments yet.</p>";
                             }
                            ?> 
                        </div>
                    </section>

                    <section id="preferences" class="profile-section">
                        <h2>Preferences</h2>
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                            <div class="form-group">
                                <label for="favorite-sports">Favorite Sports</label>
                                <select id="favorite-sports" name="favorite-sports[]" multiple>
                                    <?php foreach ($sportsData as $sport): ?>
                                        <option value="<?php echo $sport['sport_id']; ?>" <?php echo in_array($sport['sport_id'], $userData['favorite_sports']) ? 'selected' : ''; ?>>
                                            <?php echo $sport['sport_name']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="favorite-teams">Favorite SPU Teams</label>
                                <select id="favorite-teams" name="favorite-teams[]" multiple>
                                    <?php foreach ($teamsData as $team): ?>
                                        <option value="<?php echo $team['team_id']; ?>" <?php echo in_array($team['team_id'], $userData['favorite_teams']) ? 'selected' : ''; ?>>
                                            <?php echo $team['team_name']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary" name="update-preferences">Save Preferences</button>
                        </form>
                        <?php if (!empty($preferencesError)): ?>
                            <div class="error-message"><?php echo $preferencesError; ?></div>
                        <?php endif; ?>
                        <?php if (!empty($preferencesSuccess)): ?>
                            <div class="success-message"><?php echo $preferencesSuccess; ?></div>
                        <?php endif; ?>
                    </section>

                    <section id="security" class="profile-section">
                        <h2>Security</h2>
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                            <div class="form-group">
                                <label for="current-password">Current Password</label>
                                <input type="password" id="current-password" name="current-password" required>
                            </div>
                            <div class="form-group">
                                <label for="new-password">New Password</label>
                                <input type="password" id="new-password" name="new-password" required>
                            </div>
                            <div class="form-group">
                                <label for="confirm-password">Confirm New Password</label>
                                <input type="password" id="confirm-password" name="confirm-password" required>
                            </div>
                            <button type="submit" class="btn btn-primary" name="change-password">Change Password</button>
                        </form>
                        <?php if (!empty($passwordError)): ?>
                            <div class="error-message"><?php echo $passwordError; ?></div>
                        <?php endif; ?>
                        <?php if (!empty($passwordSuccess)): ?>
                            <div class="success-message"><?php echo $passwordSuccess; ?></div>
                        <?php endif; ?>
                    </section>

                    <!-- Delete Account Section -->
                    <section id="delete-account" class="profile-section">
                        <h2>Delete Account</h2>

                        <p>Are you sure you want to delete your account? This action cannot be undone.</p>

                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                            <button type="submit" class="btn btn-danger" name="delete-account">Delete Account</button> 
                        </form>

                        <?php if (!empty($deleteError)): ?>
                            <div class="error-message"><?php echo $deleteError; ?></div>
                        <?php endif; ?>
                    </section>

                </div> 
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?> 

    <!-- Confirmation Modal (Hidden by default) -->
    <?php if (isset($showDeleteConfirmation) && $showDeleteConfirmation): ?>
    <div id="deleteConfirmationModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">×</span>
            <h2>Confirm Account Deletion</h2>
            <p>Are you absolutely sure you want to delete your account? This cannot be reversed.</p>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                <button type="submit" class="btn btn-danger" name="confirm-delete-account">Yes, Delete</button>
                <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <script src="/scripts/profile.js"></script> 
    <script>
            <?php if (isset($showDeleteConfirmation) && $showDeleteConfirmation): ?>
            // Automatically show the modal if the flag is set
            document.getElementById("deleteConfirmationModal").style.display = "block";
            <?php endif; ?>
    </script>
</body>

</html>

<?php
// Close the database connection
mysqli_close($conn);
?>