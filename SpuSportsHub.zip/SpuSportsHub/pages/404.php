<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Not Found | Sol Plaatje University Sports Hub</title>
    <link rel="stylesheet" href="/styles/404.css">
    <link rel="stylesheet" href="/styles/header.css">
    <link rel="stylesheet" href="/styles/footer.css"> 
</head>
<body>
    
    <?php include 'header.php'; ?> 

    <main>
        <div class="error-container">
            <img src="/images/404.png" alt="404 Error" class="error-image"> 
            <h1>Oops! Page Not Found</h1>
            <p>The page you were looking for might have been moved, removed, or doesn't exist.</p>
            <a href="/pages/home.php" class="btn btn-primary">Go Back Home</a>
        </div>
    </main>

    <?php include 'footer.php'; ?>

</body>
</html>