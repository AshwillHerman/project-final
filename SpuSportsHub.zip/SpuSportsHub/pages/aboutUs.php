<?php
// aboutus.php - This file displays the About Us page content

// Database connection details (although not directly used in this file)
$servername = "127.0.0.1";
$username = "root";
$password = "Kd0783820098"; 
$dbname = "SPUSportsHub";

// Create a connection to the database (not used in this specific file but included for consistency)
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection was successful 
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Us | Sol Plaatje University Sports Hub</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn about Sol Plaatje University Sports Hub - our mission, vision, history, and the dedicated team behind fostering a vibrant sports culture at SPU.">
    <!-- 3rd Party Links -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Roboto:wght@400;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" href="/images/favicon.ico" type="image/x-icon"> 
    <!-- Custom Stylesheets -->
    <link rel="stylesheet" href="/styles/aboutUs.css"> 
</head>
<body>
    <?php include 'header.php'; ?> <!-- Include the header -->

    <main>
        <section class="hero about-hero">
            <div class="container hero-container">
                <div class="hero-content">
                    <h1>About SPU Sports Hub</h1>
                    <p>Fostering athletic excellence and community spirit at Sol Plaatje University</p>
                </div>
            </div>
        </section>

        <section class="mission-vision">
            <div class="container">
                <h2>Our Mission & Vision</h2>
                <div class="mission-vision-grid">
                    <div class="mission">
                        <img src="/images/mission.jpg" alt="Mission Image" class="mission-vision-image">
                        <h3>Our Mission</h3>
                        <p>To empower SPU students through sports by:</p>
                        <ul>
                            <li>Providing accessible opportunities for all</li>
                            <li>Supporting athletes to reach their full potential</li>
                            <li>Fostering school spirit and camaraderie</li>
                            <li>Promoting a healthy and balanced lifestyle</li>
                        </ul>
                    </div>
                    <div class="vision">
                        <img src="/images/vision.jpg" alt="Vision Image" class="mission-vision-image">
                        <h3>Our Vision</h3>
                        <p>We envision SPU as a beacon of sporting excellence, known for:</p>
                        <ul>
                            <li>Competitive athletic programs</li>
                            <li>A passionate community of supporters</li>
                            <li>Commitment to holistic student development</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <section class="history">
        <div class="container">
            <h2>A Legacy of Sporting Excellence</h2>
            <div class="timeline">
                <div class="timeline-item">
                    <div class="timeline-content">
                        <h3><i class="fas fa-trophy"></i> 2017</h3>
                        <ul>
                            <li><i class="fas fa-chess"></i> Chess: Individual bronze medal (3rd position) at the South African Open</li>
                            <li><i class="fas fa-table-tennis"></i> Tennis: USSA team selection to represent CUCSA and FASU (Selwin Cloete)</li>
                        </ul>
                        <div class="details">
                            <p>SPU athletes began making their mark in 2017, with the chess team winning an individual bronze medal and the tennis team earning prestigious representation opportunities.</p>
                        </div>
                    </div>
                </div>

                <div class="timeline-item">
                    <div class="timeline-content">
                        <h3><i class="fas fa-trophy"></i> 2019</h3>
                        <ul>
                            <li><i class="fas fa-futbol"></i> Football: Team promoted to USSA A section</li>
                            <li><i class="fas fa-table-tennis"></i> Tennis: USSA team selection to represent CUCSA and FASU (Selwin Cloete and June-Ann George)</li>
                        </ul>
                        <div class="details">
                            <p>2019 was a big year for SPU sports, with the football team moving up to the USSA A section and the tennis team continuing to excel at the continental level.</p>
                        </div>
                    </div>
                </div>

                <div class="timeline-item">
                    <div class="timeline-content">
                        <h3><i class="fas fa-trophy"></i> 2021</h3>
                        <ul>
                            <li><i class="fas fa-hockey-puck"></i> Hockey: USSA Men's Hockey Finalist B section, Ladies 3rd place</li>
                        </ul>
                        <div class="details">
                            <p>The SPU hockey teams showcased their skills in 2021, with the men's team reaching the USSA finals and the ladies' team securing 3rd place.</p>
                        </div>
                    </div>
                </div>

                <div class="timeline-item">
                    <div class="timeline-content">
                        <h3><i class="fas fa-trophy"></i> 2023</h3>
                        <ul>
                            <li><i class="fas fa-football-ball"></i> Rugby: SPU rugby team triumphs over DUT with a 59-5 victory</li>
                        </ul>
                        <div class="details">
                            <p>SPU's rugby team made a strong statement in 2023 with a dominant performance, showcasing their growth and teamwork on the field.</p>
                        </div>
                    </div>
                </div>

                <div class="timeline-item">
                    <div class="timeline-content">
                        <h3><i class="fas fa-trophy"></i> 2024</h3>
                        <ul>
                            <li><i class="fas fa-football-ball"></i> Rugby: SPU rugby team secures dominant victory, eyes Varsity Shield qualification</li>
                            <li><i class="fas fa-futbol"></i> Football: SPU footballer shines on international stage</li>
                            <li><i class="fas fa-chess"></i> Chess: Celima Mundama qualifies for FISU WUC MIND SPORTS event in Uganda</li>
                        </ul>
                        <div class="details">
                            <p>2024 continues to bring success for SPU sports, with the rugby team pushing for Varsity Shield qualification, football receiving international recognition, and chess making strides on the global stage.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


        <section class="team">
            <div class="container">
                <h2>Meet Our Coaches</h2>
                <div class="team-grid">
                    <!-- Karate -->
                    <div class="coach-card">
                        <img src="/images/karate-coach.png" alt="Karate Sensei">
                        <h3>Shihan Simphiwe Dlulane</h3>
                        <p>Karate Sensei</p>
                        <div class="coach-bio">
                           <p>Cell: 083 780 5384 </p>
                           <p>Email: simphiwe.dlulane@spu.ac.za</p>
                        </div>
                    </div>
                    <!-- Rugby -->
                    <div class="coach-card">
                        <img src="/images/rugby-coach.png" alt="Rugby Coach"> 
                        <h3>Jacques Ollie Mew</h3>
                        <p>Rugby Head Coach</p>
                        <div class="coach-bio">
                            <p>Cell: 082 527 7274 / 082 531 7493</p>
                           <p>Email: jacques.mew@spu.ac.za</p>
                        </div>
                    </div>
                    <!-- Football (Male) -->
                    <div class="coach-card">
                        <img src="/images/football-coach.png" alt="Football Coach">
                        <h3>Martin Donald Mojaki</h3>
                        <p>Football Head Coach (Male)</p>
                        <div class="coach-bio">
                           <p>Cell: 072 542 2777</p>
                           <p>Email: donald.mojaki@spu.ac.za</p>
                        </div>
                    </div>
                    <!-- Football (Female) -->
                    <div class="coach-card">
                        <img src="/images/football-coach-female.png" alt="Football Coach">
                        <h3>Tumi Veldman</h3>
                        <p>Football Head Coach (Female)</p>
                        <div class="coach-bio">
                           <p>Cell: 072 692 8620</p>
                           <p>Email: tumi.veldman@spu.ac.za</p>
                        </div>
                    </div>
                    <!-- Netball -->
                    <div class="coach-card">
                    <img src="/images/PlaceholderM.jpeg" alt="Cross Country Coach">
                        <!-- <img src="/images/netball-coach.jpg" alt="Netball Coach">  -->
                        <h3>Tlhalefo Mokopudi</h3>
                        <p>Netball Volunteer Coach</p>
                        <div class="coach-bio">
                           <p>Cell: 060 491 6932</p>
                           <p>Email: tlhalefo.mokopudi@spu.ac.za</p>
                        </div>
                    </div>
                    <!-- Golf -->
                    <div class="coach-card">
                    <img src="/images/PlaceholderM.jpeg" alt="Cross Country Coach">
                        <!-- <img src="/images/golf-coach.jpg" alt="Golf Coach"> -->
                        <h3>Nikeo Sonqishe</h3>
                        <p>Golf Head Coach</p>
                        <div class="coach-bio">
                           <p>Cell: 079 694 3438</p>
                           <p>Email: nikelo.sonqishe@spu.ac.za</p>
                        </div>
                    </div>
                    <!-- Hockey -->
                    <div class="coach-card">
                        <img src="/images/hockey-coach.png" alt="Hockey Coach">
                        <h3>Farhad “Freddy” Adams</h3>
                        <p>Hockey Head Coach</p>
                        <div class="coach-bio">
                           <p>Cell: 074 266 2043</p>
                           <p>Email: farhad.adams@spu.ac.za</p>
                        </div>
                    </div>
                    <!-- Aerobics/Dance Sport -->
                    <div class="coach-card">
                        <img src="/images/aerobics-coach.png" alt="Aerobics/Dance Sport Coach">
                        <h3>Katlego Khunou</h3>
                        <p>Aerobics/Dance Sport Head Coach</p>
                        <div class="coach-bio">
                           <p>Cell: 071 192 3252</p>
                           <p>Email: katlego.khunou@spu.ac.za</p>
                        </div>
                    </div>
                    <!-- Volleyball -->
                    <div class="coach-card">
                        <img src="/images/volleyball-coach.png" alt="Volleyball Coach">
                        <h3>Peter Mamabolo</h3>
                        <p>Volleyball Head Coach</p>
                        <div class="coach-bio">
                            <p>Cell: 082 086 8804</p>
                           <p>Email: peter.mamabolo@spu.ac.za</p>
                        </div>
                    </div>
                    <!-- Chess -->
                    <div class="coach-card">
                        <img src="/images/chess-coach.png" alt="Chess Coach">
                        <h3>Xolani Mathebula</h3>
                        <p>Chess Coach</p>
                        <div class="coach-bio">
                           <p>Cell: 062 433 5230</p>
                           <p>Email: ceboxolani@gmail.com</p>
                        </div>
                    </div>
                    <!-- Cheerleading -->
                    <div class="coach-card">
                        <img src="/images/cheerleading-coach.png" alt="Cheerleading Coach">
                        <h3>Haroldene Veldsman</h3>
                        <p>Cheerleading Coach</p>
                        <div class="coach-bio">
                           <p>Cell: 084 350 8744</p>
                           <p>Email: haroldene.veldsman@spu.ac.za</p>
                        </div>
                    </div>
                    <!-- Tennis -->
                    <div class="coach-card">
                        <img src="/images/tennis-coach.png" alt="Tennis Coach">
                        <h3>Nolan van der Merwe</h3>
                        <p>Tennis Head Coach</p>
                        <div class="coach-bio">
                           <p>Cell: 074 266 2043</p>
                           <p>Email: nolan.vandermerwe@spu.ac.za</p>
                        </div>
                    </div>
                    <!-- Table Tennis -->
                    <div class="coach-card">
                        <img src="/images/table-tennis-coach.png" alt="Table Tennis Coach">
                        <h3>Neville Parker</h3>
                        <p>Table Tennis Coach</p>
                        <div class="coach-bio">
                           <p>Cell: 074 266 2043</p>
                           <p>Email: neville.parker@hotmail.com</p>
                        </div>
                    </div>
                    <!-- Cricket -->
                    <div class="coach-card">
                        <img src="/images/cricket-coach.png" alt="Cricket Coach">
                        <h3>Anthony Mabuya</h3>
                        <p>Cricket Head Coach</p>
                        <div class="coach-bio">
                           <p>Cell: 074 578 0033</p>
                           <p>Email: anthonymabuya@spu.ac.za</p>
                        </div>
                    </div>
                    <!-- Athletics – Track & Field -->
                    <div class="coach-card">
                        <img src="/images/athletics-coach.png" alt="Athletics Coach">
                        <h3>Gys Smith</h3>
                        <p>Athletics Track and Field Coach</p>
                        <div class="coach-bio">
                           <p>Cell: 082 302 0393</p>
                           <p>Email: Gysbert.smith@spu.ac.za</p>
                        </div>
                    </div>
                    <!-- Cross Country -->
                    <div class="coach-card">
                        <img src="/images/PlaceholderM.jpeg" alt="Cross Country Coach">
                        <!-- <img src="/images/cross-country-coach.png" alt="Cross Country Coach"> -->
                        <h3>Frik Guys</h3>
                        <p>Cross Country Coach</p>
                        <div class="coach-bio">
                           <p>Cell: 073 617 5905</p>
                           <p>Email: frik.guys@spu.ac.za</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="contact-athletics">
            <div class="container">
                <h2>Connect with SPU Athletics</h2>
                <div class="contact-grid">
                    <div class="contact-info">
                        <h3>Contact Information</h3>
                        <ul>
                            <li><i class="fas fa-envelope"></i> <a href="mailto:athletics@spu.ac.za">athletics@spu.ac.za</a></li>
                            <li><i class="fas fa-phone"></i> +27 (0)53 491 0123</li>
                            <li><i class="fas fa-map-marker-alt"></i> SPU Sports Complex, Building A</li>
                        </ul>
                    </div>
                    <div class="social-media">
                        <h3>Follow Us</h3>
                        <div class="social-icons">
                            <a href="https://www.facebook.com/SolPlaatjeUniv/" aria-label="Facebook"><i class="fab fa-facebook"></i></a>
                            <a href="https://twitter.com/MySPU?mx=2" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                            <a href="https://www.instagram.com/sol_plaatje_university/" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <script src="/scripts/aboutUs.js"></script>

    <?php 
    // Include the footer
    include 'footer.php'; 

    // Close the database connection
    mysqli_close($conn); 
    ?>
</body>
</html>