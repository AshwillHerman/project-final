<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Sol Plaatje University Sports Hub - Stay connected with SPU athletics, explore sports, view schedules, and shop for team gear.">

    <!-- 3rd Party Stylesheets -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Roboto:wght@400;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Favicon -->
    <link rel="icon" href="/images/favicon.ico" type="image/x-icon">

    <!-- Custom Stylesheets -->
    <link rel="stylesheet" href="/styles/header.css">
    <link rel="stylesheet" href="/styles/footer.css">
</head>
<body>

    <!-- Header Section -->
    <header>
        <div class="container header-container">
            <!-- Logo -->
            <a href="/" class="logo">
                <img src="/images/logo.png" alt="Sol Plaatje University Logo" width="100" height="50">
            </a>

            <!-- Header Text -->
            <div class="header-text">
                <h1>Sol Plaatje University <span>Sports Hub</span></h1>
            </div>

            <!-- Navigation -->
            <nav>
                <ul>
                    <li><a href="/pages/home.php">Home</a></li>
                    <li><a href="/pages/sports.php">Sports</a></li>
                    <li><a href="/pages/schedules&Results.html">Schedules & Results</a></li>
                    <li><a href="/pages/shop.html">Shop</a></li>
                    <li><a href="/pages/community.html">Community</a></li>
                    <li><a href="/pages/aboutUs.php">About Us</a></li>

                    <!-- Profile Link (replace with actual user profile link) -->
                    <li id="profile-link">
                        <a href="/pages/profile.php">
                            <i class="fas fa-user-circle"></i>
                        </a>
                    </li>

                    <!-- Cart Icon -->
                    <li id="cart-icon">
                        <a aria-label="Shopping Cart">
                            <i class="fas fa-shopping-cart"></i>
                            <span id="cart-count">0</span>
                        </a>
                    </li>

                    <!-- Login/Register Link -->
                    <li id="login-register-link">
                        <a href="/pages/registration.php" class="btn-login">Login/Register</a>
                    </li>
                </ul>
            </nav>
        </div>
    </header>