<?php
// home.php

// Include the header file
include 'header.php';

// Database connection details
$servername = "127.0.0.1";
$username = "root";
$password = "Kd0783820098"; 
$dbname = "SPUSportsHub";

// Create a connection to the database
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Function to fetch featured news articles from the database
function getFeaturedNews($conn) {
    $sql = "SELECT * FROM News ORDER BY created_at DESC LIMIT 3";
    $result = mysqli_query($conn, $sql);
    $news = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $news[] = $row;
    }
    return $news;
}

// Function to fetch upcoming events from the database
function getUpcomingEvents($conn) {
    $sql = "SELECT * FROM Events WHERE event_date >= CURDATE() ORDER BY event_date ASC LIMIT 4";
    $result = mysqli_query($conn, $sql);
    $events = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $events[] = $row;
    }
    return $events;
}

// Function to fetch live scores from the database
function getLiveScores($conn) {
    $sql = "SELECT * FROM Events WHERE is_live = 1";
    $result = mysqli_query($conn, $sql);
    $scores = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $scores[] = $row;
    }
    return $scores;
}

// Function to fetch shop products from the database
function getShopProducts($conn) {
    $sql = "SELECT * FROM Products";
    $result = mysqli_query($conn, $sql);
    $products = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $products[] = $row;
    }
    return $products;
}

// Fetch dynamic content using the defined functions
$featuredNews = getFeaturedNews($conn);
$upcomingEvents = getUpcomingEvents($conn);
$liveScores = getLiveScores($conn);
$shopProducts = getShopProducts($conn);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Home | Sol Plaatje University Sports Hub</title>
    <link rel="stylesheet" href="/styles/home.css">
</head>


<body>

<?php include 'header.php'; ?>

<main>
    <!-- Hero Section -->
    <section class="hero">
        <div class="container hero-container">
            <div class="hero-content">
                <h2>Welcome to the SPU Sports Hub!</h2>
                <p>Stay connected with all things SPU athletics. Explore sports, view schedules, connect with the community, and shop for your favorite team gear.</p>
                <a href="/pages/sports.html" class="btn">Explore Sports</a>
                <a href="/pages/schedules&Results.html" class="btn btn-secondary">Upcoming Events</a>
            </div>
        </div>
    </section>

    <!-- Featured News Section -->
    <section class="featured-news">
        <div class="container">
            <h2>Featured News & Announcements</h2>
            <div class="news-container">
                <?php foreach ($featuredNews as $newsItem): ?>
                    <div class="news-item">
                        <img src="<?php echo $newsItem['image_url']; ?>" alt="<?php echo $newsItem['title']; ?>">
                        <div class="news-text">
                            <h3><a href="/pages/community.html"><?php echo $newsItem['title']; ?></a></h3>
                            <p><?php echo $newsItem['content']; ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Live Scores Section -->
    <section class="live-scores">
        <div class="container">
            <div class="section-header">
                <h2>Live Scores</h2>
                <a href="/pages/schedules&Results.html" class="view-all-scores">View All Scores <i class="fas fa-chevron-right"></i></a>
            </div>
            <div class="score-ticker-container" id="scoreTickerContainer">
                <div class="score-ticker" id="scoreTicker">
                    <?php foreach ($liveScores as $score): ?>
                        <div class="score-item" data-sport="<?php echo $score['sport_id']; ?>">
                            <i class="fas fa-futbol"></i> 
                            <div class="score-details">
                                <div class="team-names"><?php echo $score['home_team_id']; ?> vs. <?php echo $score['away_team_id']; ?></div>
                                <div class="score"><?php echo $score['score_home']; ?> - <?php echo $score['score_away']; ?></div>
                            </div>
                            <span class="sport-tag"><?php echo $score['sport_id']; ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="controls">
                <button id="pauseBtn" class="control-btn"><i class="fas fa-pause"></i> Pause</button>
                <button id="resumeBtn" class="control-btn"><i class="fas fa-play"></i> Resume</button>
            </div>
        </div>
    </section>

    <!-- Upcoming Events Section -->
    <section class="upcoming-events">
        <div class="container">
            <h2>Upcoming Events</h2>
            <div class="event-list">
                <?php foreach ($upcomingEvents as $event): ?>
                    <div class="event-item">
                        <div class="event-date">
                            <span class="day"><?php echo date('d', strtotime($event['event_date'])); ?></span>
                            <span class="month"><?php echo date('M', strtotime($event['event_date'])); ?></span>
                        </div>
                        <div class="event-details">
                            <h3><?php echo $event['title']; ?></h3>
                            <p><i class="fas fa-clock"></i> Time: <?php echo date('H:i', strtotime($event['event_date'])); ?></p>
                            <p><i class="fas fa-map-marker-alt"></i> <?php echo $event['venue']; ?></p>
                            <a href="#" class="btn btn-small">More Info</a> 
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <a href="#" class="btn btn-secondary view-all-events">View Full Calendar</a> 
        </div>
    </section>

    <!-- Sports Spotlight Section -->
    <section class="sports-spotlight">
        <div class="container">
            <h2>Sports Spotlight</h2>
            <div class="spotlight-content">
                <!-- Left Side: Carousel (replace with dynamic data from the database) -->
                <div class="spotlight-left">
                    <div class="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active"><img src="/images/netball-champions.jpg" alt="Netball Champions"></div>
                            <div class="carousel-item"><img src="/images/rugby-varsity-shield.jpg" alt="Rugby Varsity Shield"></div>
                            <div class="carousel-item"><img src="/images/colour-run-participants.jpg" alt="Colour Run Participants"></div>
                        </div>
                        <button class="carousel-control prev" aria-label="Previous slide"><i class="fas fa-chevron-left"></i></button>
                        <button class="carousel-control next" aria-label="Next slide"><i class="fas fa-chevron-right"></i></button>
                        <div class="carousel-nav"></div>
                    </div>
                    <div class="carousel-caption">
                        <h3>Latest Sports Events</h3>
                        <p>Experience the excitement of SPU's diverse sports scene!</p>
                    </div>
                </div>

                <!-- Right Side: Video Highlight (replace with dynamic data from the database) -->
                <div class="spotlight-right">
                    <div class="video-container">
                        <video id="spotlight-video" controls poster="/images/rugby-varsity-shield.jpg">
                            <source src="/video/highlights.mp4" type="video/mp4">
                            Your browser does not support the video tag. 
                        </video>
                    </div>
                    <div class="video-description">
                        <h3>SPU Sports Highlights</h3>
                        <p>Witness the talent and determination of our athletes in various events. From intense chess matches to high-energy athletics and exciting soccer games, there's something for every sports enthusiast.</p>
                        <div class="video-actions">
                            <button class="btn btn-primary" id="shareBtn"><i class="fas fa-share"></i> Share</button> 
                            <button class="btn btn-secondary" id="moreVideosBtn"><i class="fas fa-list"></i> More Videos</button> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Shop Showcase Section -->
    <section class="shop-showcase">
        <div class="container">
            <h2>Shop SPU Gear</h2>
            <div class="product-list">
                <?php foreach ($shopProducts as $product): ?>
                    <div class="card" data-id="<?php echo $product['product_id']; ?>" data-name="<?php echo $product['product_name']; ?>" data-price="<?php echo $product['price']; ?>">
                        <div class="card-img" style="background-image: url('/images/<?php echo $product['image_url']; ?>');"></div>
                        <div class="card-info">
                            <h3 class="text-title"><?php echo $product['product_name']; ?></h3>
                            <p class="text-body"><?php echo $product['description']; ?></p>
                        </div>
                        <div class="card-footer">
                            <span class="text-title">R<?php echo $product['price']; ?></span>
                            <button class="card-button add-to-cart">
                                <i class="fas fa-shopping-cart"></i> Add to Cart
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Size Selection Modal -->
    <div id="sizeModal" class="modal">
        <div class="modal-content">
            <span class="close-modal">×</span>
            <h2>Select Size</h2>
            <form id="sizeForm">
                <label>
                    <input type="radio" name="size" value="Small"> Small
                </label>
                <label>
                    <input type="radio" name="size" value="Medium"> Medium
                </label>
                <label>
                    <input type="radio" name="size" value="Large"> Large
                </label>
                <button type="submit" class="btn">Add to Cart</button>
            </form>
        </div>
    </div>

    <!-- Cart Pop-Up -->
    <div id="cartPopup" class="cart-popup">
        <div class="cart-popup-content">
            <span class="close-cart">×</span>
            <h2>Your Cart</h2>
            <ul id="cart-items"></ul>
            <div class="cart-total">Total: R<span id="cart-total">0.00</span></div>
            <div class="cart-actions">
                <button id="checkoutBtn" class="btn">Proceed to Checkout</button> 
                <button id="clearCartBtn" class="btn btn-secondary">Clear Cart</button> 
            </div>
        </div>
    </div>

    <!-- Testimonials Section -->
    <section class="testimonials">
        <div class="container">
            <h2>What Our Athletes Say</h2>
            <div class="testimonial-slider" id="testimonialSlider">
                <!-- Testimonials will be dynamically inserted here -->
            </div>
        </div>
    </section>

    <!-- Newsletter Signup Section -->
    <section class="newsletter">
        <div class="container">
            <h2>Stay Updated</h2>
            <p>Subscribe to our newsletter for the latest SPU sports news and events.</p>
            <form id="newsletterForm" class="newsletter-form">
                <input type="email" placeholder="Enter your email" required>
                <button type="submit" class="btn">Subscribe</button>
            </form>
        </div>
    </section>
</main>

<?php

// Include the footer file
include 'footer.php';

// Close the database connection
mysqli_close($conn);

?>