<?php
/**
 * sports.php - This file displays the Sports page content, dynamically fetching 
 *              sports information from the database.
 */

// Database connection details
$servername = "127.0.0.1";
$username = "root";
$password = "Kd0783820098"; 
$dbname = "SPUSportsHub";

// Create a connection to the database
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection was successful 
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// SQL query to fetch all sports from the database
$sql = "SELECT * FROM Sports"; 

// Execute the query
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sports | Sol Plaatje University Sports Hub</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Sol Plaatje University Sports Hub - Stay connected with SPU athletics, explore sports, view schedules, and shop for team gear.">
        
    <!-- 3RD PARTY LINKS -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Roboto:wght@400;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" href="/images/favicon.ico" type="image/x-icon">

    <!-- CUSTOM STYLESHEETS -->
    <link rel="stylesheet" href="/styles/sports.css"> 

</head>
<body>
    <?php include 'header.php'; ?> <!-- Include the header file -->

    <main role="main">
        <section class="section hero sports-hero">
            <div class="container hero-container">
                <div class="hero-content">
                    <h2>Discover SPU Sports</h2>
                    <p>Explore our diverse range of sports programs and find your passion. Whether you're a seasoned athlete or just starting out, there's a place for you in our sports community.</p>
                </div>
            </div>
        </section>

        <section id="sports-grid" class="section sports-grid">
            <div class="section-container">
                <h2>Our Sports Programs</h2>
                <div class="grid">
                    <?php 
                    // Check if any sports were found in the database
                    if (mysqli_num_rows($result) > 0) {
                        // Loop through each sport
                        while($row = mysqli_fetch_assoc($result)) { 
                            ?>
                            <div class="sport-card">
                                <img src="<?php echo $row['image_url']; ?>" alt="<?php echo $row['sport_name']; ?>" loading="lazy">
                                <div class="sport-card-content">
                                    <h3><?php echo $row['sport_name']; ?></h3>
                                    <p><?php echo $row['description']; ?></p>
                                    <a href="sport_details.php?id=<?php echo $row['sport_id']; ?>" class="btn-sport">Learn More</a> 
                                </div>
                            </div>
                            <?php
                        }
                    } else {
                        // Display a message if no sports were found
                        echo "<p>No sports found.</p>";
                    }
                    ?>
                </div> 
            </div>
        </section>

        <div class="banner">
            <img src="/images/banner.jpg" alt="SPU Sports Banner" class="banner">
        </div>

        <section class="section sports-cta">
            <div class="section-container">
                <h2>Get Involved in SPU Sports</h2>
                <p>Whether you're a seasoned athlete or just starting out, there's a place for you in our sports programs. Join a team, attend events, or show your support as a fan!</p>
                <a href="#" class="btn-join">Join a Team</a>
            </div>
        </section>
    </main>

    <script src="/scripts/sports.js"></script>
   
   <?php 
    // Include the footer
    include 'footer.php'; 

    // Close the database connection
    mysqli_close($conn); 
    ?>
</body>
</html>