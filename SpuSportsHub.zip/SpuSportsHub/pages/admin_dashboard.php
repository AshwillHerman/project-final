<?php
// Start the session to manage user login status
session_start();

// Database connection details (you should have these stored securely, e.g., in a config file)
$servername = "127.0.0.1";
$username = "root";
$password = "Kd0783820098"; 
$dbname = "SPUSportsHub";

// Create a connection to the database
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in and is an admin
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["is_admin"] !== 1) {
    header("Location: /pages/registration.php"); // Redirect to login page if not logged in or not an admin
    exit;
}

// Function to sanitize user inputs to prevent security vulnerabilities like XSS
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// 1. Fetch data for the dashboard
// --- Get the counts for users, products, orders, etc.
$sql = "SELECT 
        (SELECT COUNT(*) FROM Users) AS total_users, 
        (SELECT COUNT(*) FROM Products) AS total_products, 
        (SELECT COUNT(*) FROM Orders) AS total_orders,
        (SELECT COUNT(*) FROM News) AS total_news,
        (SELECT COUNT(*) FROM Events) AS total_events,
        (SELECT COUNT(*) FROM Sports) AS total_sports"; // Added counts for news, events, and sports

$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Error fetching dashboard data: " . mysqli_error($conn));
}

$dashboardData = mysqli_fetch_assoc($result);

// 2. Handle form submissions and other admin actions

// ---- 2.1 Update Score ----
if (isset($_POST['update_score'])) {
    $eventId = sanitizeInput($_POST['event_id']);
    $homeScore = sanitizeInput($_POST['home_score']);
    $awayScore = sanitizeInput($_POST['away_score']);

    $sql = "UPDATE Events SET score_home = ?, score_away = ? WHERE event_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "iii", $homeScore, $awayScore, $eventId);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: admin.php#events"); // Redirect back to the Events section of the dashboard
    } else {
        // Error handling
        echo "Error updating score: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}

// ---- 2.2 Add Match ----
if (isset($_POST['add_match'])) {
    $homeTeamId = sanitizeInput($_POST['home_team_id']);
    $awayTeamId = sanitizeInput($_POST['away_team_id']);
    $sportId = sanitizeInput($_POST['sport_id']);
    $eventDate = sanitizeInput($_POST['event_date']);
    $eventTime = sanitizeInput($_POST['event_time']);
    $venue = sanitizeInput($_POST['venue']);

    // Combine date and time into a single datetime string
    $eventDateTime = $eventDate . ' ' . $eventTime;

    $sql = "INSERT INTO Events (home_team_id, away_team_id, sport_id, event_date, venue, score_home, score_away, is_live) 
            VALUES (?, ?, ?, ?, ?, 0, 0, 0)"; // Initial scores are 0, is_live is 0 (not live) by default
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "iisss", $homeTeamId, $awayTeamId, $sportId, $eventDateTime, $venue);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: admin.php#events"); // Redirect back to the Events section
    } else {
        echo "Error adding match: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}

// ---- 2.3 Edit Product ----
if (isset($_POST['edit_product'])) {
    $productId = sanitizeInput($_POST['product-id']);
    $productName = sanitizeInput($_POST['product-name']);
    $productDescription = sanitizeInput($_POST['product-description']);
    $productCategory = sanitizeInput($_POST['product-category']);
    $productPrice = sanitizeInput($_POST['product-price']);
    $productStock = sanitizeInput($_POST['product-stock']);

    // Handle image upload if a new image is selected
    if (isset($_FILES['product-image']) && $_FILES['product-image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = "../images/";
        $targetFile = $targetDir . basename($_FILES["product-image"]["name"]);
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Check if image file is valid
        $check = getimagesize($_FILES["product-image"]["tmp_name"]);
        if ($check === false) {
            echo "File is not an image.";
            exit;
        }

        // Allow certain file formats
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
            echo "Sorry, only JPG, JPEG, and PNG files are allowed.";
            exit;
        }

        // Try to upload the file
        if (move_uploaded_file($_FILES["product-image"]["tmp_name"], $targetFile)) {
            $productImage = basename($_FILES["product-image"]["name"]);

            // Update database with the new image name
            $sql = "UPDATE Products SET 
                    product_name = ?, 
                    description = ?, 
                    category = ?, 
                    price = ?, 
                    stock_quantity = ?,
                    image_url = ? 
                    WHERE product_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "sssdiss", $productName, $productDescription, $productCategory, $productPrice, $productStock, $productImage, $productId);
        } else {
            echo "Sorry, there was an error uploading your file.";
            exit;
        }
    } else {
        // Update product details without changing the image
        $sql = "UPDATE Products SET 
                product_name = ?, 
                description = ?, 
                category = ?, 
                price = ?, 
                stock_quantity = ? 
                WHERE product_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssdsi", $productName, $productDescription, $productCategory, $productPrice, $productStock, $productId);
    }

    if (mysqli_stmt_execute($stmt)) {
        header("Location: admin.php#store"); // Redirect back to the Store section
    } else {
        echo "Error editing product: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}

// ---- 2.4 Delete Product ----
if (isset($_GET['delete_product'])) {
    $productId = sanitizeInput($_GET['delete_product']);

    $sql = "DELETE FROM Products WHERE product_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $productId);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: admin.php#store"); // Redirect back to the Store section
    } else {
        echo "Error deleting product: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}

// ---- 2.5 Add Product ----
if (isset($_POST['add_product'])) {
    $productName = sanitizeInput($_POST['product-name']);
    $productDescription = sanitizeInput($_POST['product-description']);
    $productCategory = sanitizeInput($_POST['product-category']);
    $productPrice = sanitizeInput($_POST['product-price']);
    $productStock = sanitizeInput($_POST['product-stock']);

    // Handle image upload 
    if (isset($_FILES['product-image']) && $_FILES['product-image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = "../images/";
        $targetFile = $targetDir . basename($_FILES["product-image"]["name"]);
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Check if image file is valid
        $check = getimagesize($_FILES["product-image"]["tmp_name"]);
        if ($check === false) {
            echo "File is not an image.";
            exit;
        }

        // Allow certain file formats
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
            echo "Sorry, only JPG, JPEG, and PNG files are allowed.";
            exit;
        }

        // Try to upload the file
        if (move_uploaded_file($_FILES["product-image"]["tmp_name"], $targetFile)) {
            $productImage = basename($_FILES["product-image"]["name"]);

            // Insert new product into database
            $sql = "INSERT INTO Products (product_name, description, category, price, stock_quantity, image_url) 
                    VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "sssdis", $productName, $productDescription, $productCategory, $productPrice, $productStock, $productImage);
        } else {
            echo "Sorry, there was an error uploading your file.";
            exit;
        }
    } else {
        echo "Error: No image file selected.";
        exit;
    }

    if (mysqli_stmt_execute($stmt)) {
        header("Location: admin.php#store"); // Redirect back to the Store section
    } else {
        echo "Error adding product: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}
// ---- 2.6 Edit User ----
if (isset($_POST['edit_user'])) {
    $userId = sanitizeInput($_POST['user-id']);
    $fullName = sanitizeInput($_POST['full-name']);
    $email = sanitizeInput($_POST['email']);
    $studentId = sanitizeInput($_POST['student-id']);
    $staffId = sanitizeInput($_POST['staff-id']);
    $isAdmin = isset($_POST['is_admin']) ? 1 : 0; // Check if admin checkbox is checked

    $sql = "UPDATE Users SET 
            full_name = ?, 
            email = ?, 
            student_number = ?, 
            staff_number = ?, 
            is_admin = ? 
            WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssssii", $fullName, $email, $studentId, $staffId, $isAdmin, $userId);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: admin.php#users"); // Redirect back to the Users section
    } else {
        echo "Error editing user: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}

// ---- 2.7 Delete User ----
if (isset($_GET['delete_user'])) {
    $userId = sanitizeInput($_GET['delete_user']);

    $sql = "DELETE FROM Users WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $userId);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: admin.php#users"); // Redirect back to the Users section
    } else {
        echo "Error deleting user: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}

// ---- 2.8 Add Article ---- 
if (isset($_POST['add_article'])) {
    $articleTitle = sanitizeInput($_POST['article-title']);
    $articleAuthor = sanitizeInput($_POST['article-author']);
    $articleContent = sanitizeInput($_POST['article-content']);
    $articleStatus = sanitizeInput($_POST['article-status']); // Assuming you have a status field

    // Handle image upload if an image is selected
    if (isset($_FILES['article-image']) && $_FILES['article-image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = "../images/"; // Directory to store uploaded images
        $targetFile = $targetDir . basename($_FILES["article-image"]["name"]);
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Check if image file is valid
        $check = getimagesize($_FILES["article-image"]["tmp_name"]);
        if ($check !== false) {
            // Allow certain file formats
            if ($imageFileType == "jpg" || $imageFileType == "png" || $imageFileType == "jpeg" || $imageFileType == "gif") {
                // If no errors, try to upload the file
                if (move_uploaded_file($_FILES["article-image"]["tmp_name"], $targetFile)) {
                    $articleImage = basename($_FILES["article-image"]["name"]);

                    // Insert new article into the database (including image)
                    $sql = "INSERT INTO News (title, author, content, status, image_url, created_at) 
                            VALUES (?, ?, ?, ?, ?, NOW())";
                    $stmt = mysqli_prepare($conn, $sql);
                    mysqli_stmt_bind_param($stmt, "sssss", $articleTitle, $articleAuthor, $articleContent, $articleStatus, $articleImage);
                } else {
                    echo "Sorry, there was an error uploading your file.";
                    exit;
                }
            } else {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                exit;
            }
        } else {
            echo "File is not an image.";
            exit;
        }
    } else {
        // Insert new article without an image
        $sql = "INSERT INTO News (title, author, content, status, created_at) 
                VALUES (?, ?, ?, ?, NOW())";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssss", $articleTitle, $articleAuthor, $articleContent, $articleStatus);
    }

    if (mysqli_stmt_execute($stmt)) {
        header("Location: admin.php#content"); // Redirect back to the Content section
    } else {
        echo "Error adding article: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}


// ---- 2.9 Edit Article ----
if (isset($_POST['edit_article'])) {
    $articleId = sanitizeInput($_POST['article-id']);
    $articleTitle = sanitizeInput($_POST['article-title']);
    $articleAuthor = sanitizeInput($_POST['article-author']);
    $articleContent = sanitizeInput($_POST['article-content']);
    $articleStatus = sanitizeInput($_POST['article-status']);

    // Handle image upload if a new image is selected
    if (isset($_FILES['article-image']) && $_FILES['article-image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = "../images/";
        $targetFile = $targetDir . basename($_FILES["article-image"]["name"]);
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Check if image file is valid
        $check = getimagesize($_FILES["article-image"]["tmp_name"]);
        if ($check === false) {
            echo "File is not an image.";
            exit;
        }

        // Allow certain file formats
        if ($imageFileType == "jpg" || $imageFileType == "png" || $imageFileType == "jpeg" || $imageFileType == "gif") {
            // If no errors, try to upload the file
            if (move_uploaded_file($_FILES["article-image"]["tmp_name"], $targetFile)) {
                $articleImage = basename($_FILES["article-image"]["name"]);

                // Update database with the new image name
                $sql = "UPDATE News SET 
                        title = ?, 
                        author = ?, 
                        content = ?, 
                        status = ?, 
                        image_url = ? 
                        WHERE news_id = ?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "sssssi", $articleTitle, $articleAuthor, $articleContent, $articleStatus, $articleImage, $articleId);
            } else {
                echo "Sorry, there was an error uploading your file.";
                exit;
            }
        } else {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            exit;
        }
    } else {
        // Update article details without changing the image
        $sql = "UPDATE News SET 
                title = ?, 
                author = ?, 
                content = ?, 
                status = ? 
                WHERE news_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssssi", $articleTitle, $articleAuthor, $articleContent, $articleStatus, $articleId);
    }

    if (mysqli_stmt_execute($stmt)) {
        header("Location: admin.php#content"); // Redirect back to the Content section
    } else {
        echo "Error editing article: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}

// ---- 2.10 Delete Article ----
if (isset($_GET['delete_article'])) {
    $articleId = sanitizeInput($_GET['delete_article']);

    $sql = "DELETE FROM News WHERE news_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $articleId);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: admin.php#content"); // Redirect back to the Content section
    } else {
        echo "Error deleting article: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}


// ---- 2.11 Add Sport ----
if (isset($_POST['add_sport'])) {
    $sportName = sanitizeInput($_POST['sport-name']);
    $sportDescription = sanitizeInput($_POST['sport-description']); 

    // Handle image upload
    if (isset($_FILES['sport-image']) && $_FILES['sport-image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = "../images/";
        $targetFile = $targetDir . basename($_FILES["sport-image"]["name"]);
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Check if image file is valid
        $check = getimagesize($_FILES["sport-image"]["tmp_name"]);
        if ($check === false) {
            echo "File is not an image.";
            exit;
        }

        // Allow certain file formats
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
            echo "Sorry, only JPG, JPEG, and PNG files are allowed.";
            exit;
        }

        // Try to upload the file
        if (move_uploaded_file($_FILES["sport-image"]["tmp_name"], $targetFile)) {
            $sportImage = basename($_FILES["sport-image"]["name"]);

            // Insert new sport into database
            $sql = "INSERT INTO Sports (sport_name, description, image_url) 
                    VALUES (?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "sss", $sportName, $sportDescription, $sportImage); 

        } else {
            echo "Sorry, there was an error uploading your file.";
            exit;
        }
    } else {
        echo "Error: No image file selected.";
        exit;
    }

    if (mysqli_stmt_execute($stmt)) {
        header("Location: admin.php#sports"); 
    } else {
        echo "Error adding sport: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}

// ---- 2.12 Edit Sport ----
if (isset($_POST['edit_sport'])) {
    $sportId = sanitizeInput($_POST['sport-id']);
    $sportName = sanitizeInput($_POST['sport-name']);
    $sportDescription = sanitizeInput($_POST['sport-description']);

    // Handle image upload if a new image is selected
    if (isset($_FILES['sport-image']) && $_FILES['sport-image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = "../images/"; 
        $targetFile = $targetDir . basename($_FILES["sport-image"]["name"]);
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Check if image file is valid
        $check = getimagesize($_FILES["sport-image"]["tmp_name"]);
        if ($check === false) {
            echo "File is not an image.";
            exit;
        }

        // Allow certain file formats
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
            echo "Sorry, only JPG, JPEG, and PNG files are allowed.";
            exit;
        }

        // Try to upload the file
        if (move_uploaded_file($_FILES["sport-image"]["tmp_name"], $targetFile)) {
            $sportImage = basename($_FILES["sport-image"]["name"]);

            // Update database with the new image name
            $sql = "UPDATE Sports SET 
                    sport_name = ?, 
                    description = ?, 
                    image_url = ? 
                    WHERE sport_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "sssi", $sportName, $sportDescription, $sportImage, $sportId);
        } else {
            echo "Sorry, there was an error uploading your file.";
            exit;
        }
    } else {
        // Update sport details without changing the image
        $sql = "UPDATE Sports SET 
                sport_name = ?, 
                description = ? 
                WHERE sport_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssi", $sportName, $sportDescription, $sportId);
    }

    if (mysqli_stmt_execute($stmt)) {
        header("Location: admin.php#sports"); 
    } else {
        echo "Error editing sport: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}


// ---- 2.13 Delete Sport ----
if (isset($_GET['delete_sport'])) {
    $sportId = sanitizeInput($_GET['delete_sport']);

    $sql = "DELETE FROM Sports WHERE sport_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $sportId);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: admin.php#sports"); 
    } else {
        echo "Error deleting sport: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}

// ... Implement other admin functions (approvePost(), deletePost(), flagPost(), etc.) ...

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPU Sports Hub Admin Panel</title>
    <link rel="stylesheet" href="/styles/admin.css"> 
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="admin-panel">

        <aside class="sidebar">
            <a href="#" class="logo">
                <img src="/images/logo.png" alt="SPU Sports Hub Logo" width="100" height="50"> 
            </a>
            <nav>
                <ul>
                    <li><a href="#dashboard" class="active">Dashboard</a></li>
                    <li><a href="#content">Content Management</a></li>
                    <li><a href="#store">Store Management</a></li>
                    <li><a href="#users">User Management</a></li>
                    <li><a href="#community">Community Management</a></li>
                    <li><a href="#sports">Sports Management</a></li> 
                    <li><a href="#events">Events Management</a></li> 
                </ul>
            </nav>
            <a href="logout.php" class="logout-button">Log Out</a> 
        </aside>

        <div class="main-content">

            <header class="top-bar">
                <div class="user-info">
                    <span class="username">Welcome, <?php echo $_SESSION["username"]; ?></span> 
                    <img src="/images/karate-coach.png" alt="User Avatar" class="user-avatar">
                </div>
            </header>

            <section id="dashboard" class="section active">
                <h2>Dashboard</h2>
                <div class="dashboard-grid">
                    <!-- Users Card -->
                    <div class="dashboard-card primary-color">
                        <h3>Total Users</h3>
                        <div class="metric"><?php echo $dashboardData['total_users']; ?></div>
                    </div>

                    <!-- Products Card -->
                    <div class="dashboard-card secondary-color">
                        <h3>Total Products</h3>
                        <div class="metric"><?php echo $dashboardData['total_products']; ?></div>
                    </div>

                    <!-- Orders Card -->
                    <div class="dashboard-card tertiary-color">
                        <h3>Total Orders</h3>
                        <div class="metric"><?php echo $dashboardData['total_orders']; ?></div>
                    </div>

                    <!-- News Articles Card -->
                    <div class="dashboard-card">
                        <h3>Total News Articles</h3>
                        <div class="metric"><?php echo $dashboardData['total_news']; ?></div>
                    </div>

                    <!-- Events Card -->
                    <div class="dashboard-card">
                        <h3>Total Events</h3>
                        <div class="metric"><?php echo $dashboardData['total_events']; ?></div>
                    </div>

                    <!-- Sports Card -->
                    <div class="dashboard-card">
                        <h3>Total Sports</h3>
                        <div class="metric"><?php echo $dashboardData['total_sports']; ?></div>
                    </div>

                    <!-- Recent Activity Card -->
                    <div class="dashboard-card accent-color">
                        <h3>Recent Activity</h3>
                        <ul id="activity-stream">
                            <!-- Sample Activity Stream Items (Replace with Dynamic Content from DB) -->
                            <li>New user registration: John Doe</li>
                            <li>New order placed (Order ID: #12345)</li>
                            <li>Forum post pending approval: "Excited for the game!" by SPUFan1</li>
                        </ul>
                    </div>
                </div>
            </section>

            <section id="content" class="section">
                <h2>Content Management</h2>
                <h3>News Articles</h3>
                <div class="table-toolbar">
                    <input type="text" id="articleSearch" placeholder="Search articles...">
                    <button class="btn btn-primary" onclick="openModal('article-modal')">Create Article</button>
                </div>
                <table id="articles-table">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Fetch news articles from the database
                        $sql = "SELECT * FROM News";
                        $result = mysqli_query($conn, $sql);

                        if ($result) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                $articleId = $row['news_id'];
                                $title = $row['title'];
                                $author = $row['author']; 
                                $date = $row['created_at'];
                                $status = $row['status']; 

                                // Display the article information in a table row
                                echo "<tr data-article-id='$articleId'>"; // Added data attribute for article ID
                                echo "<td>$title</td>";
                                echo "<td>$author</td>";
                                echo "<td>$date</td>";
                                echo "<td class='status-" . strtolower($status) . "'>$status</td>"; 
                                echo "<td>";
                                echo "<button onclick=\"editArticle('article-modal', $articleId)\">Edit</button>";
                                echo "<a href='admin.php?delete_article=$articleId' onclick=\"return confirm('Are you sure you want to delete this article?');\">Delete</a>"; // Changed to a link with confirmation
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5'>Error fetching articles.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </section>

            <section id="store" class="section">
                <h2>Store Management</h2>
                <h3>Products</h3>
                <div class="table-toolbar">
                    <input type="text" id="productSearch" placeholder="Search products...">
                    <button class="btn btn-primary" onclick="openModal('product-modal')">Add Product</button>
                </div>
                <table id="products-table">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Fetch products from the database
                        $sql = "SELECT * FROM Products";
                        $result = mysqli_query($conn, $sql);

                        if ($result) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                $productId = $row['product_id'];
                                $productName = $row['product_name'];
                                $productCategory = $row['category'];
                                $productPrice = $row['price'];
                                $productStock = $row['stock_quantity'];
                                $productImage = $row['image_url'];

                                // Display the product information in a table row
                                echo "<tr data-product-id='$productId'>"; // Added data attribute for product ID
                                echo "<td><img src='/images/$productImage' alt='$productName'></td>";
                                echo "<td>$productName</td>";
                                echo "<td>$productCategory</td>";
                                echo "<td>R$productPrice</td>";
                                echo "<td>$productStock</td>";
                                echo "<td>";
                                echo "<button onclick=\"editProduct('product-modal', $productId)\">Edit</button>";
                                echo "<a href='admin.php?delete_product=$productId' onclick=\"return confirm('Are you sure you want to delete this product?');\">Delete</a>"; // Changed to a link with confirmation
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='6'>Error fetching products.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </section>

            <section id="users" class="section">
                <h2>User Management</h2>
                <h3>Users</h3>
                <div class="table-toolbar">
                    <input type="text" id="userSearch" placeholder="Search users...">
                </div>
                <table id="users-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Student ID</th> 
                            <th>Staff ID</th>
                            <th>Role</th> 
                            <th>Registration Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Fetch users from the database
                        $sql = "SELECT * FROM Users";
                        $result = mysqli_query($conn, $sql);

                        if ($result) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                $userId = $row['user_id'];
                                $fullName = $row['full_name'];
                                $email = $row['email'];
                                $studentId = $row['student_number'];
                                $staffId = $row['staff_number'];
                                $isAdmin = $row['is_admin'] ? 'Admin' : 'User';
                                $registrationDate = $row['registration_date'];

                                // Display the user information in a table row
                                echo "<tr data-user-id='$userId'>"; // Added data attribute for user ID
                                echo "<td>$fullName</td>";
                                echo "<td>$email</td>";
                                echo "<td>$studentId</td>"; 
                                echo "<td>$staffId</td>"; 
                                echo "<td>$isAdmin</td>";
                                echo "<td>$registrationDate</td>";
                                echo "<td>";
                                echo "<button onclick=\"editUser('user-modal', $userId)\">Edit</button>";
                                echo "<a href='admin.php?delete_user=$userId' onclick=\"return confirm('Are you sure you want to delete this user?');\">Delete</a>"; // Changed to a link with confirmation
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7'>Error fetching users.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </section>

            <section id="community" class="section">
                <h2>Community Management</h2>
                <h3>Forum Posts</h3>
                <div class="table-toolbar">
                    <input type="text" id="postSearch" placeholder="Search posts...">
                </div>
                <table id="posts-table">
                    <thead>
                        <tr>
                            <th>Post Title</th>
                            <th>Author</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Sample Data - Replace with actual posts from your database -->
                        <!-- You'll need to dynamically populate this table --> 
                        <!-- Each row should have data attributes for post ID, status, etc. -->
                        <!-- Use appropriate classes for the status (e.g., status-pending, status-approved, status-flagged) -->
                        <!-- Example Row: -->
                        <!-- 
                        <tr data-post-id="1" data-status="pending">
                            <td>Excited for the Game!</td>
                            <td>John Doe123</td>
                            <td>2023-07-20</td>
                            <td class="status-pending">Pending</td> 
                            <td>
                                <button onclick="approvePost(1)">Approve</button>
                                <button onclick="deletePost(1)">Delete</button>
                            </td>
                        </tr>
                        --> 
                    </tbody>
                </table>
            </section>

            <!-- Sports Management Section -->
            <section id="sports" class="section">
                <h2>Sports Management</h2>
                <h3>Sports</h3>
                <div class="table-toolbar">
                    <input type="text" id="sportSearch" placeholder="Search sports...">
                    <button class="btn btn-primary" onclick="openModal('sport-modal')">Add Sport</button>
                </div>
                <table id="sports-table">
                    <thead>
                        <tr>
                            <th>Sport Name</th>
                            <th>Description</th>
                            <th>Image</th> 
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Fetch sports from the database
                        $sql = "SELECT * FROM Sports";
                        $result = mysqli_query($conn, $sql);

                        if ($result) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                $sportId = $row['sport_id'];
                                $sportName = $row['sport_name'];
                                $sportDescription = $row['description'];
                                $sportImage = $row['image_url'];

                                // Display the sport information in a table row
                                echo "<tr data-sport-id='$sportId'>"; 
                                echo "<td>$sportName</td>";
                                echo "<td>$sportDescription</td>";
                                echo "<td><img src='/images/$sportImage' alt='$sportName'></td>"; 
                                echo "<td>";
                                echo "<button onclick=\"editSport('sport-modal', $sportId)\">Edit</button>";
                                echo "<a href='admin.php?delete_sport=$sportId' onclick=\"return confirm('Are you sure you want to delete this sport?');\">Delete</a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='4'>Error fetching sports.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </section>

            <section id="events" class="section">
                <h2>Events Management</h2>
                <h3>Upcoming Events</h3>
                <div class="table-toolbar">
                    <input type="text" id="upcomingEventSearch" placeholder="Search events...">
                    <button class="btn btn-primary" onclick="openModal('add-match-modal')">Add Match</button>
                </div>
                <table id="upcoming-events-table">
                    <thead>
                        <tr>
                            <th>Sport</th>
                            <th>Home Team</th>
                            <th>Away Team</th>
                            <th>Date and Time</th>
                            <th>Venue</th>
                            <th>Score</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Fetch upcoming events from the database
                        $sql = "SELECT e.*, s.sport_name, t1.team_name AS home_team_name, t2.team_name AS away_team_name
                                FROM Events e
                                JOIN Sports s ON e.sport_id = s.sport_id
                                JOIN Teams t1 ON e.home_team_id = t1.team_id
                                JOIN Teams t2 ON e.away_team_id = t2.team_id
                                WHERE e.event_date >= CURDATE()
                                ORDER BY e.event_date ASC";
                        $result = mysqli_query($conn, $sql);

                        if ($result) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                $eventId = $row['event_id'];
                                $sportName = $row['sport_name'];
                                $homeTeamName = $row['home_team_name'];
                                $awayTeamName = $row['away_team_name'];
                                $eventDateTime = $row['event_date'];
                                $venue = $row['venue'];
                                $homeScore = $row['score_home'];
                                $awayScore = $row['score_away'];

                                echo "<tr data-event-id='$eventId'>";
                                echo "<td>$sportName</td>";
                                echo "<td>$homeTeamName</td>";
                                echo "<td>$awayTeamName</td>";
                                echo "<td>$eventDateTime</td>";
                                echo "<td>$venue</td>";
                                echo "<td id='score-$eventId'>$homeScore - $awayScore</td>"; // Display current score
                                echo "<td>";
                                echo "<button onclick=\"openModal('update-score-modal', $eventId)\">Update Score</button>"; 
                                // ... add other actions like edit or delete if needed
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7'>Error fetching events.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>

                <h3>Past Events</h3>
                <!-- Add a similar table for past events, possibly with different actions --> 
            </section>
        </div>
    </div> 

    <!-- Modals -->

    <!-- Add Article Modal -->
    <div class="modal" id="article-modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal('article-modal')">×</span>
            <h2>Article Details</h2>
            <form id="article-form" method="post" action="admin.php" enctype="multipart/form-data">
                <input type="hidden" id="article-id" name="article-id"> 

                <label for="article-title">Title:</label>
                <input type="text" id="article-title" name="article-title" required><br><br>

                <label for="article-author">Author:</label>
                <input type="text" id="article-author" name="article-author" required><br><br>

                <label for="article-content">Content:</label>
                <textarea id="article-content" name="article-content" rows="5" required></textarea><br><br>

                <label for="article-status">Status:</label>
                <select id="article-status" name="article-status">
                    <option value="Draft">Draft</option>
                    <option value="Published">Published</option>
                </select><br><br>

                <label for="article-image">Image:</label>
                <input type="file" id="article-image" name="article-image"><br><br> 

                <input type="submit" name="add_article" value="Add Article" class="btn btn-primary"> 
                <input type="submit" name="edit_article" value="Save Changes" class="btn btn-primary" style="display: none;"> 
            </form>
        </div>
    </div>

    <!-- Add Product Modal -->
    <div class="modal" id="product-modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal('product-modal')">×</span>
            <h2>Product Details</h2>
            <form id="product-form" method="post" action="admin.php" enctype="multipart/form-data">
                <input type="hidden" id="product-id" name="product-id">

                <label for="product-name">Name:</label>
                <input type="text" id="product-name" name="product-name" required><br><br>

                <label for="product-description">Description:</label>
                <textarea id="product-description" name="product-description" rows="3" required></textarea><br><br>

                <label for="product-category">Category:</label>
                <select id="product-category" name="product-category" required>
                    <option value="clothing">Clothing</option>
                    <option value="accessories">Accessories</option>
                    <option value="equipment">Equipment</option>
                    <!-- Add more categories as needed -->
                </select><br><br>

                <label for="product-price">Price (R):</label>
                <input type="number" id="product-price" name="product-price" step="0.01" required><br><br>

                <label for="product-stock">Stock Quantity:</label>
                <input type="number" id="product-stock" name="product-stock" required><br><br>

                <label for="product-image">Image:</label>
                <input type="file" id="product-image" name="product-image"><br><br> 

                <input type="submit" name="add_product" value="Add Product" class="btn btn-primary">
                <input type="submit" name="edit_product" value="Save Changes" class="btn btn-primary" style="display: none;">
            </form>
        </div>
    </div>

    <!-- Edit User Modal -->
    <div class="modal" id="user-modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal('user-modal')">×</span>
            <h2>User Details</h2>
            <form id="user-form" method="post" action="admin.php">
                <input type="hidden" id="user-id" name="user-id">

                <label for="full-name">Full Name:</label>
                <input type="text" id="full-name" name="full-name" required><br><br>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required><br><br>

                <label for="student-id">Student ID:</label>
                <input type="text" id="student-id" name="student-id"><br><br>

                <label for="staff-id">Staff ID:</label>
                <input type="text" id="staff-id" name="staff-id"><br><br>

                <input type="checkbox" id="is_admin" name="is_admin">
                <label for="is_admin">Admin</label><br><br>

                <input type="submit" name="edit_user" value="Save Changes" class="btn btn-primary">
            </form>
        </div>
    </div>

    <!-- Add Sport Modal -->
    <div class="modal" id="sport-modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal('sport-modal')">×</span>
            <h2>Sport Details</h2>
            <form id="sport-form" method="post" action="admin.php" enctype="multipart/form-data"> 
                <input type="hidden" id="sport-id" name="sport-id">

                <label for="sport-name">Sport Name:</label>
                <input type="text" id="sport-name" name="sport-name" required><br><br>

                <label for="sport-description">Description:</label>
                <textarea id="sport-description" name="sport-description" rows="3"></textarea><br><br>

                <label for="sport-image">Image:</label>
                <input type="file" id="sport-image" name="sport-image"><br><br>

                <input type="submit" name="add_sport" value="Add Sport" class="btn btn-primary">
                <input type="submit" name="edit_sport" value="Save Changes" class="btn btn-primary" style="display: none;"> 
            </form>
        </div>
    </div>

    <!-- Update Score Modal -->
    <div class="modal" id="update-score-modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal('update-score-modal')">×</span>
            <h2>Update Score</h2>
            <form id="update-score-form" method="post" action="admin.php">
                <input type="hidden" id="update-event-id" name="event_id"> 

                <label for="home_score">Home Team Score:</label>
                <input type="number" id="home_score" name="home_score" min="0" required><br><br>

                <label for="away_score">Away Team Score:</label>
                <input type="number" id="away_score" name="away_score" min="0" required><br><br>

                <input type="submit" name="update_score" value="Update Score" class="btn btn-primary">
            </form>
        </div>
    </div>

    <!-- Add Match Modal -->
    <div class="modal" id="add-match-modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal('add-match-modal')">×</span>
            <h2>Add Match</h2>
            <form id="add-match-form" method="post" action="admin.php">
                <label for="sport_id">Sport:</label>
                <select id="sport_id" name="sport_id" required>
                    <?php
                    // Fetch sports from the database for the dropdown
                    $sql = "SELECT * FROM Sports";
                    $sportsResult = mysqli_query($conn, $sql);

                    if ($sportsResult) {
                        while ($sport = mysqli_fetch_assoc($sportsResult)) {
                            echo "<option value='" . $sport['sport_id'] . "'>" . $sport['sport_name'] . "</option>";
                        }
                    } else {
                        echo "<option value=''>Error fetching sports</option>";
                    }
                    ?>
                </select><br><br>

                <label for="home_team_id">Home Team:</label>
                <select id="home_team_id" name="home_team_id" required>
                    <?php
                    // Fetch teams from the database for the dropdown
                    $sql = "SELECT * FROM Teams";
                    $teamsResult = mysqli_query($conn, $sql);

                    if ($teamsResult) {
                        while ($team = mysqli_fetch_assoc($teamsResult)) {
                            echo "<option value='" . $team['team_id'] . "'>" . $team['team_name'] . "</option>";
                        }
                    } else {
                        echo "<option value=''>Error fetching teams</option>";
                    }
                    ?>
                </select><br><br>

                <label for="away_team_id">Away Team:</label>
                <select id="away_team_id" name="away_team_id" required>
                    <?php
                    // Use the same teams result as for the home team dropdown
                    if ($teamsResult) {
                        mysqli_data_seek($teamsResult, 0); // Reset result pointer
                        while ($team = mysqli_fetch_assoc($teamsResult)) {
                            echo "<option value='" . $team['team_id'] . "'>" . $team['team_name'] . "</option>";
                        }
                    } else {
                        echo "<option value=''>Error fetching teams</option>";
                    }
                    ?>
                </select><br><br>

                <label for="event_date">Date:</label>
                <input type="date" id="event_date" name="event_date" required><br><br>

                <label for="event_time">Time:</label>
                <input type="time" id="event_time" name="event_time" required><br><br>

                <label for="venue">Venue:</label>
                <input type="text" id="venue" name="venue" required><br><br>

                <input type="submit" name="add_match" value="Add Match" class="btn btn-primary">
            </form>
        </div>
    </div>

    <script src="/scripts/admin.js"></script> 
    <script>
        function editArticle(modalId, articleId) {
            // Fetch the article data from the server using AJAX
            fetch(`/get_article_details.php?article_id=${articleId}`) 
                .then(response => response.json())
                .then(articleData => {
                    // Populate the modal form fields with the article data
                    document.getElementById('article-id').value = articleData.news_id;
                    document.getElementById('article-title').value = articleData.title;
                    document.getElementById('article-author').value = articleData.author;
                    document.getElementById('article-content').value = articleData.content;
                    document.getElementById('article-status').value = articleData.status; 

                    // Hide "Add Article" button, show "Save Changes" button
                    document.querySelector('#article-form input[name="add_article"]').style.display = 'none';
                    document.querySelector('#article-form input[name="edit_article"]').style.display = 'inline-block';

                    // Open the modal
                    openModal(modalId);
                })
                .catch(error => {
                    console.error('Error fetching article details:', error);
                    alert('Error loading article details. Please try again later.'); 
                });
        }

        function editProduct(modalId, productId) {
            fetch(`/get_product_details.php?product_id=${productId}`)
                .then(response => response.json())
                .then(productData => {
                    document.getElementById('product-id').value = productData.product_id;
                    document.getElementById('product-name').value = productData.product_name;
                    document.getElementById('product-description').value = productData.description;
                    document.getElementById('product-category').value = productData.category;
                    document.getElementById('product-price').value = productData.price;
                    document.getElementById('product-stock').value = productData.stock_quantity;
                    // For the image, you might want to display the current image and allow the user to upload a new one

                    // Hide "Add Product" button, show "Save Changes" button
                    document.querySelector('#product-form input[name="add_product"]').style.display = 'none';
                    document.querySelector('#product-form input[name="edit_product"]').style.display = 'inline-block';

                    openModal(modalId);
                })
                .catch(error => {
                    console.error('Error fetching product details:', error);
                    alert('Error loading product details. Please try again later.'); 
                });
        }

        function editUser(modalId, userId) {
            fetch(`/get_user_details.php?user_id=${userId}`)
                .then(response => response.json())
                .then(userData => {
                    document.getElementById('user-id').value = userData.user_id;
                    document.getElementById('full-name').value = userData.full_name;
                    document.getElementById('email').value = userData.email;
                    document.getElementById('student-id').value = userData.student_number;
                    document.getElementById('staff-id').value = userData.staff_number;
                    document.getElementById('is_admin').checked = userData.is_admin === 1;

                    openModal(modalId);
                })
                .catch(error => {
                    console.error('Error fetching user details:', error);
                    alert('Error loading user details. Please try again later.');
                });
        }

        function editSport(modalId, sportId) {
            fetch(`/get_sport_details.php?sport_id=${sportId}`)
                .then(response => response.json())
                .then(sportData => {
                    document.getElementById('sport-id').value = sportData.sport_id;
                    document.getElementById('sport-name').value = sportData.sport_name;
                    document.getElementById('sport-description').value = sportData.description;
                    // For the image, you might want to display the current image and allow the user to upload a new one

                    // Hide "Add Sport" button, show "Save Changes" button
                    document.querySelector('#sport-form input[name="add_sport"]').style.display = 'none';
                    document.querySelector('#sport-form input[name="edit_sport"]').style.display = 'inline-block';

                    openModal(modalId);
                })
                .catch(error => {
                    console.error('Error fetching sport details:', error);
                    alert('Error loading sport details. Please try again later.'); 
                });
        }

        function deleteSport(sportId) {
            if (confirm(`Are you sure you want to delete this sport? This action cannot be undone.`)) {
                // Redirect to the admin.php page with the delete_sport parameter
                window.location.href = `admin.php?delete_sport=${sportId}`;
            }
        }

        function openModal(modalId, eventId = null) {
            const modal = document.getElementById(modalId);
            modal.classList.add('active');

            // If it's the update score modal, populate the event ID
            if (modalId === 'update-score-modal' && eventId !== null) {
                document.getElementById('update-event-id').value = eventId;
            }
        }


        // 4. Table Search Functionality (add search for events table)
        createTableSearch('upcomingEventSearch', 'upcoming-events-table'); 

        
    </script>
</body> 
</html>