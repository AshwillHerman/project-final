<?php

// Start the session (if not already started)
session_start();

// Database connection details (you should have these stored securely, e.g., in a config file)
$servername = "127.0.0.1";
$username = "root";
$password = "Iam2002$"; 
$dbname = "SPUSportsHub";

// Create a connection to the database
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

/**
 * Sanitizes user inputs to prevent security vulnerabilities like XSS.
 *
 * @param string $data The input data to sanitize.
 * @return string The sanitized data.
 */
function sanitizeInput($data) {
    $data = trim($data); // Remove whitespace from beginning and end
    $data = stripslashes($data); // Remove backslashes 
    $data = htmlspecialchars($data); // Convert special characters to HTML entities
    return $data;
}

// Initialize error and success messages
$error = "";
$success = "";

// Check if the token is provided in the URL
if (isset($_GET["token"])) {
    $token = sanitizeInput($_GET["token"]); // Sanitize the token

    // Check if the token is valid and not expired
    $sql = "SELECT * FROM password_resets WHERE token='$token' AND expiry_date > NOW()";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $email = $row["email"];

        // Handle password reset form submission
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $newPassword = sanitizeInput($_POST["new-password"]);
            $confirmPassword = sanitizeInput($_POST["confirm-password"]);

            if ($newPassword == $confirmPassword) {
                // Hash the new password
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

                // Update the password in the Users table
                $sql = "UPDATE Users SET password='$hashedPassword' WHERE email='$email'";
                
                if (mysqli_query($conn, $sql)) {
                    // Delete the token from the password_resets table
                    $sql = "DELETE FROM password_resets WHERE token='$token'";
                    mysqli_query($conn, $sql);

                    $success = "Password reset successfully. You can now login with your new password.";
                } else {
                    $error = "Error updating password in database.";
                }

            } else {
                $error = "Passwords do not match.";
            }
        }

        // Display the password reset form if no errors or success message
        if (!$error && !$success): 
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Reset Password | Sol Plaatje University Sports Hub</title>
            <link rel="stylesheet" href="password_resets.css"> 
            <!-- Link to your CSS file -->
        </head>
        <body>
            <div class="auth-section">
                <div class="auth-container">
                    <h2>Reset Password</h2>
            
                    <?php if ($error): ?>
                        <div class="error-message"><?php echo $error; ?></div>
                    <?php endif; ?>
            
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . "?token=" . $token; ?>" method="POST"> 
                        <div class="input-group">
                            <label for="new-password">New Password:</label>
                            <input type="password" id="new-password" name="new-password" required>
                        </div>
                        <div class="input-group">
                            <label for="confirm-password">Confirm Password:</label>
                            <input type="password" id="confirm-password" name="confirm-password" required>
                        </div>
                        <button type="submit" class="btn">Reset Password</button>
                    </form>
                </div>
            </div>
        </body>
        </html>
        <?php 
        endif; // End of password reset form display

    } else {
        $error = "Invalid or expired token.";
    }
} else {
    $error = "Token not provided.";
}

// Display error or success messages outside the form (if any)
if ($error || $success):
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | Sol Plaatje University Sports Hub</title>
    <link rel="stylesheet" href="/styles/password_resets.css"> 
    <!-- Link to your CSS file -->
</head>
<body>
<?php include 'header.php'; ?>

    <div class="auth-section">
        <div class="auth-container">
            <h2>Reset Password</h2>
    
            <?php if ($error): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>
    
            <?php if ($success): ?>
                <div class="success-message"><?php echo $success; ?></div>
            <?php endif; ?>
        </div>
    </div>

    <?php include 'footer.php'; ?>

</body>
</html>
<?php
endif; 

// Close the database connection
mysqli_close($conn);
?>