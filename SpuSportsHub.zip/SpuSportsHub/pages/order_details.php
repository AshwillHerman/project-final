<?php
// Start the session
session_start();

// Database connection details
$servername = "127.0.0.1";
$username = "root";
$password = "Kd0783820098";
$dbname = "SPUSportsHub";

// Create a connection to the database
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection was successful
if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
header("Location: /pages/registration.php"); // Redirect to login page
exit;
}

// Get the order ID from the URL
if (isset($_GET['order_id'])) {
$orderId = intval($_GET['order_id']); // Sanitize the input using intval()

// Fetch order details from the database
$sql = "SELECT o.order_id, o.order_date, o.total_amount, o.status, o.shipping_address, o.payment_method,
oi.quantity, p.product_name, p.price
FROM Orders o
JOIN OrderItems oi ON o.order_id = oi.order_id
JOIN Products p ON oi.product_id = p.product_id
WHERE o.order_id = $orderId"; // Use sanitized $orderId in the query

$result = mysqli_query($conn, $sql);

if ($result) {
$orderDetails = [];
while ($row = mysqli_fetch_assoc($result)) {
$orderDetails[] = $row;
}

// Check if any order details were found
if (!empty($orderDetails)) {
// Extract order information for easier access in the view
$orderDate = $orderDetails[0]['order_date'];
$totalAmount = $orderDetails[0]['total_amount'];
$status = $orderDetails[0]['status'];
$shippingAddress = $orderDetails[0]['shipping_address'];
$paymentMethod = $orderDetails[0]['payment_method'];
}
} else {
die("Error fetching order details: " . mysqli_error($conn));
}
} else {
// Handle the case where order_id is not provided in the URL
echo "Order ID not found.";
exit; // Or redirect to a different page
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Order Details | Sol Plaatje University Sports Hub</title>
<link rel="stylesheet" href="/styles/order_details.css">
<link rel="stylesheet" href="/styles/header.css">
<link rel="stylesheet" href="/styles/footer.css">
</head>
<body>
<?php include 'header.php'; ?>
<main class="order-details-section" role="main">
    <div class="container">
        <h1>Order Details</h1>

        <?php if (!empty($orderDetails)): ?>
            <h2>Order ID: <?php echo $orderId; ?></h2>
            <p>Order Date: <?php echo $orderDate; ?></p>
            <p>Total Amount: R<?php echo $totalAmount; ?></p>
            <p>Status: <?php echo $status; ?></p>
            <p>Shipping Address: <?php echo $shippingAddress; ?></p>
            <p>Payment Method: <?php echo $paymentMethod; ?></p>

            <h3>Items Ordered</h3>
            <table class="order-items-table">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orderDetails as $item): ?>
                        <tr>
                            <td><?php echo $item['product_name']; ?></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td>R<?php echo $item['price']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

        <?php else: ?>
            <p>No order details found for order ID: <?php echo $orderId; ?></p>
        <?php endif; ?>

        <a href="/pages/profile.php#order-history" class="btn btn-secondary">Back to Order History</a>
    </div>
</main>

<?php include 'footer.php'; ?>
</body>
</html>
<?php
// Close the database connection
mysqli_close($conn);
?>