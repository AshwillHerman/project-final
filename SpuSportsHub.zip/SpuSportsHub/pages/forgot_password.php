<?php

/**
 * forgot_password.php: Handles the "forgot password" process for the Sol Plaatje University Sports Hub.
 *
 * This script allows users to request a password reset link if they have forgotten their password.
 * It includes:
 * - Database connection setup
 * - Input sanitization for security
 * - Logic for generating and storing password reset tokens
 * - Email sending using PHPMailer
 * - Error and success message handling
 */

// Start the session to manage user login status (if not already started)
session_start();

// Database connection details
$servername = "127.0.0.1";
$username = "root";
$password = "Kd0783820098"; 
$dbname = "SPUSportsHub";

// Create a connection to the database
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection was successful
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

/**
 * Sanitizes user inputs to prevent security vulnerabilities like XSS.
 *
 * @param string $data The input data to sanitize.
 * @return string The sanitized data.
 */
function sanitizeInput($data)
{
    $data = trim($data); // Remove whitespace from beginning and end
    $data = stripslashes($data); // Remove backslashes
    $data = htmlspecialchars($data); // Convert special characters to HTML entities
    return $data;
}

// Initialize error and success messages
$error = "";
$success = "";

// Include PHPMailer library (assuming you have installed it using Composer)
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'C:\Users\dingi\OneDrive\Desktop\SpuSportsHub\vendor\autoload.php'; // Autoload PHPMailer classes

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = sanitizeInput($_POST["email"]);

    // Check if the email exists in the database
    $sql = "SELECT * FROM Users WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        // Generate a unique token
        $token = bin2hex(random_bytes(32));

        // **DELETE existing token for this email (if any)**
        $sql = "DELETE FROM password_resets WHERE email='$email'";
        mysqli_query($conn, $sql);

        // Store the token in the password_resets table
        $sql = "INSERT INTO password_resets (email, token, expiry_date) VALUES ('$email', '$token', DATE_ADD(NOW(), INTERVAL 1 HOUR))"; // Token expires in 1 hour

        if (mysqli_query($conn, $sql)) {
            // Send password reset email using PHPMailer
            $resetLink = "http://localhost:3000/pages/password_resets.php?token=" . $token; // **REPLACE with your actual reset password page URL**

            $mail = new PHPMailer(true);

            try {
                // Server settings (replace with your actual SMTP settings)
                $mail->SMTPDebug = SMTP::DEBUG_OFF; // Enable verbose debug output only for testing
                $mail->isSMTP();                                            // Send using SMTP
                $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
                $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
                $mail->Username   = 'Spusport3@gmail.com';                     // SMTP username
                $mail->Password   = 'Spu@Sports1';                               // SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
                $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

                // Recipients
                $mail->setFrom('Spusport3@gmail.com', 'Sol Plaatje University Sports Hub'); // Replace with your website's email and name
                $mail->addAddress($email);     // Add a recipient

                // Content
                $mail->isHTML(true);                                  // Set email format to HTML
                $mail->Subject = 'Password Reset Request';
                $mail->Body    = "Click this link to reset your password: <a href='$resetLink'>$resetLink</a>"; 

                $mail->send();
                $success = "Password reset link sent to your email.";
            } catch (Exception $e) {
                $error = "Error sending email: {$mail->ErrorInfo}"; // More specific error message
            }
        } else {
            $error = "Error storing token in database: " . mysqli_error($conn); // More specific error message
        }
    } else {
        $error = "Email not found.";
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password | Sol Plaatje University Sports Hub</title>
    <link rel="stylesheet" href="/styles/forgot_password.css">
    <link rel="stylesheet" href="/styles/header.css">
    <link rel="stylesheet" href="/styles/footer.css">
</head>
<body>

<?php include 'header.php'; ?>

<section class="auth-section">
    <div class="auth-container">
        <h2>Forgot Password</h2>

        <?php if ($error): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success-message"><?php echo $success; ?></div>
        <?php else: ?>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <div class="input-group">
                    
                <label for="email"><i class="fa fa-envelope"></i>Email:</label>
                <input type="email" id="email" name="email" required>
                <span class="input-icon">
                </span>
            </div>
                <button type="submit" class="btn">Send Reset Link</button>
            </form>
        <?php endif; ?>
    </div>
</section>

<?php include 'footer.php'; ?>

</body>
</html>

<?php
// Close the database connection
mysqli_close($conn);
?>