// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function () {

    // Get all the profile navigation links
    const profileNavLinks = document.querySelectorAll('.profile-nav a');

    // Get all the profile content sections
    const profileSections = document.querySelectorAll('.profile-content section');

    // Add click event listeners to the navigation links
    profileNavLinks.forEach(link => {
        link.addEventListener('click', function (event) {
            event.preventDefault(); // Prevent default link behavior

            // Remove the "active" class from all navigation links
            profileNavLinks.forEach(navLink => navLink.classList.remove('active'));

            // Add the "active" class to the clicked navigation link
            this.classList.add('active');

            // Hide all profile content sections
            profileSections.forEach(section => section.classList.remove('active'));

            // Show the corresponding profile content section
            const targetSectionId = this.getAttribute('href'); // Get the target section ID from the link's href attribute
            const targetSection = document.querySelector(targetSectionId);
            targetSection.classList.add('active');
        });
    });

    // Forum Tabs Functionality (if you have forum tabs)
    const forumTabs = document.querySelectorAll('.forum-tabs button');
    const forumSections = document.querySelectorAll('.forum-section');

    forumTabs.forEach(tab => {
        tab.addEventListener('click', function () {
            // Remove "active" class from all tabs and sections
            forumTabs.forEach(t => t.classList.remove('active'));
            forumSections.forEach(s => s.classList.remove('active'));

            // Add "active" class to the clicked tab and corresponding section
            this.classList.add('active');
            const targetSectionId = this.getAttribute('data-tab');
            document.getElementById(targetSectionId).classList.add('active');
        });
    });

}); 

// JavaScript to show/hide the confirmation modal
function closeModal() {
    document.getElementById("deleteConfirmationModal").style.display = "none";
}

document.getElementById('profile-picture-input').addEventListener('change', function(e) {
    const wrapper = e.target.closest('.file-upload-wrapper');
    if (e.target.files.length > 0) {
        wrapper.classList.add('file-selected');
        wrapper.querySelector('.upload-text').textContent = 'Picture selected';
    } else {
        wrapper.classList.remove('file-selected');
        wrapper.querySelector('.upload-text').textContent = 'Choose a new picture';
    }
});