// registration.js: JavaScript for handling tab switching and form interactions on the registration/login page.

// Function to show the selected tab and hide the others.
function showTab(tabId) {
  // Get all the auth forms and tabs.
  const authForms = document.querySelectorAll('.auth-form');
  const authTabs = document.querySelectorAll('.auth-tab');

  // Hide all forms and remove the 'active' class from all tabs.
  authForms.forEach(form => form.classList.remove('active'));
  authTabs.forEach(tab => tab.classList.remove('active'));

  // Show the selected form and add the 'active' class to the corresponding tab.
  const selectedForm = document.getElementById(`${tabId}-form`);
  const selectedTab = document.querySelector(`.auth-tab[data-tab="${tabId}"]`);

  if (selectedForm && selectedTab) {
    selectedForm.classList.add('active');
    selectedTab.classList.add('active');
  }
}

// Get all the auth tabs and add click event listeners to them.
const authTabs = document.querySelectorAll('.auth-tab');
authTabs.forEach(tab => {
  tab.addEventListener('click', () => {
    // Get the data-tab attribute from the clicked tab.
    const tabId = tab.dataset.tab;

    // Show the corresponding tab based on the data-tab attribute.
    showTab(tabId);
  });
});

// Show the default tab (or the tab specified in the URL parameters).
const urlParams = new URLSearchParams(window.location.search);
const activeTabFromUrl = urlParams.get('tab');

if (activeTabFromUrl && ['login', 'student-register', 'admin-register', 'admin'].includes(activeTabFromUrl)) {
  showTab(activeTabFromUrl); // Show the tab from the URL.
} else {
  showTab('login'); // Show the login tab by default.
}

// Add student number validation (example - you can customize this further)
const studentNumberInput = document.getElementById('student-number');
if (studentNumberInput) { // Check if the element exists before adding the event listener
    studentNumberInput.addEventListener('input', function() {
        if (this.value.length === 8 && /^\d+$/.test(this.value)) {
            this.classList.add('valid');
            this.classList.remove('invalid');
        } else {
            this.classList.add('invalid');
            this.classList.remove('valid');
        }
    });
}