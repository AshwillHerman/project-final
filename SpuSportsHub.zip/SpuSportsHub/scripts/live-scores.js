const socket = io();

socket.on('connect', () => {
    console.log('Connected to server');
});

socket.on('score_update', (data) => {
    updateScoreDisplay(data);
});

function updateScoreDisplay(data) {
    const matchElement = document.getElementById(`match-${data.match_id}`);
    if (matchElement) {
        matchElement.querySelector('.team1').textContent = data.team1_name;
        matchElement.querySelector('.team2').textContent = data.team2_name;
        matchElement.querySelector('.score').textContent = `${data.team1_score} - ${data.team2_score}`;
    }
}