// home.js

// Wait for the DOM to fully load before executing the script
document.addEventListener('DOMContentLoaded', () => {
    // Initialize various components of the page
    initializeCarousel();
    initializeShareButton();
    initializeMoreVideosButton();
    initializeLiveScoresTicker();
    initializeTestimonialSlider();
    initializeNewsletterForm();
    initializeShoppingCart();
});

// Function to initialize the carousel
function initializeCarousel() {
    // Select the carousel container and its elements
    const carousel = document.querySelector('.carousel');
    const carouselItems = carousel.querySelectorAll('.carousel-item');
    const carouselNav = carousel.querySelector('.carousel-nav');
    const prevButton = carousel.querySelector('.carousel-control.prev');
    const nextButton = carousel.querySelector('.carousel-control.next');

    // Keep track of the currently active slide
    let currentIndex = 0;

    // Function to create navigation dots for the carousel
    function createCarouselNav() {
        // Create a navigation dot for each carousel item
        carouselItems.forEach((_, index) => {
            const navItem = document.createElement('div');
            navItem.classList.add('carousel-nav-item');
            if (index === 0) navItem.classList.add('active'); // Set the first dot as active
            navItem.addEventListener('click', () => goToSlide(index));
            carouselNav.appendChild(navItem);
        });
    }

    // Function to navigate to a specific slide
    function goToSlide(index) {
        // Remove the 'active' class from the current slide and its corresponding navigation dot
        carouselItems[currentIndex].classList.remove('active');
        carouselNav.children[currentIndex].classList.remove('active');

        // Update the current index
        currentIndex = index;

        // Add the 'active' class to the new slide and its corresponding navigation dot
        carouselItems[currentIndex].classList.add('active');
        carouselNav.children[currentIndex].classList.add('active');
    }

    // Function to move to the next slide
    function nextSlide() {
        goToSlide((currentIndex + 1) % carouselItems.length);
    }

    // Function to move to the previous slide
    function prevSlide() {
        goToSlide((currentIndex - 1 + carouselItems.length) % carouselItems.length);
    }

    // Create navigation dots
    createCarouselNav();

    // Automatically move to the next slide every 5 seconds
    setInterval(nextSlide, 5000);

    // Add event listeners for previous and next buttons
    prevButton.addEventListener('click', prevSlide);
    nextButton.addEventListener('click', nextSlide);
}

// Function to initialize the share button functionality
function initializeShareButton() {
    // Select the share button
    const shareBtn = document.getElementById('shareBtn');

    // Check if the share button exists
    if (shareBtn) {
        // Add an event listener for the 'click' event
        shareBtn.addEventListener('click', () => {
            // Check if the browser supports the Web Share API
            if (navigator.share) {
                // Share the current page using the Web Share API
                navigator.share({
                    title: 'SPU Sports Highlights',
                    text: 'Check out the latest sports highlights from Sol Plaatje University!',
                    url: window.location.href
                })
                .then(() => {
                    console.log('Thanks for sharing!');
                })
                .catch(console.error);
            } else {
                // If the Web Share API is not supported, display an alert message
                alert('Sharing is not supported on this browser. Please copy the URL manually.');
            }
        });
    }
}

// Function to initialize the more videos button functionality (placeholder)
function initializeMoreVideosButton() {
    // Select the more videos button
    const moreVideosBtn = document.getElementById('moreVideosBtn');

    // Check if the more videos button exists
    if (moreVideosBtn) {
        // Add an event listener for the 'click' event
        moreVideosBtn.addEventListener('click', () => {
            // This is a placeholder. In a real application, you might load more videos dynamically.
            alert('More videos coming soon! Check back later for updates.');
        });
    }
}

// Data for the live scores ticker
const liveScores = [
    { teams: "SPU Men vs. Opponent Team", score: "Won - Champions", sport: "Netball" },
    { teams: "SPU Women vs. Opponent Team", score: "Won - Champions", sport: "Netball" },
    { teams: "SPU vs. TUT", score: "29 - 27", sport: "Rugby" },
    { teams: "SPU vs. DUT", score: "59 - 5", sport: "Rugby" },
    { teams: "SPU vs. University of Limpopo", score: "104 - 0", sport: "Rugby" },
    { teams: "SPU vs. Rhodes University", score: "38 - 19", sport: "Rugby" },
    { teams: "SPU 2nd team vs. Cristiana", score: "54 - 33", sport: "Rugby" },
    { teams: "SPU 1st team vs. Prieska", score: "94 - 24", sport: "Rugby" },
    { teams: "South Africa vs. Botswana", score: "3 - 0", sport: "Football" }
];

// Function to initialize the live scores ticker
function initializeLiveScoresTicker() {
    // Select the score ticker container and buttons
    const scoreTicker = document.getElementById('scoreTicker');
    const pauseBtn = document.getElementById('pauseBtn');
    const resumeBtn = document.getElementById('resumeBtn');

    // Function to update the live scores display
    function updateLiveScores() {
        // Clear the ticker
        scoreTicker.innerHTML = '';

        // Add each live score to the ticker
        liveScores.forEach(item => {
            const scoreItem = document.createElement('div');
            scoreItem.classList.add('score-item');
            scoreItem.setAttribute('data-sport', item.sport);
            scoreItem.innerHTML = `
                <i class="fas fa-futbol"></i>
                <div class="score-details">
                    <div class="team-names">${item.teams}</div>
                    <div class="score">${item.score}</div>
                </div>
                <span class="sport-tag">${item.sport}</span>
            `;
            scoreTicker.appendChild(scoreItem);
        });

        // Clone the scores and append to create the looping effect
        scoreTicker.innerHTML += scoreTicker.innerHTML;
    }

    // Initial update of the live scores
    updateLiveScores();

    // Add event listeners for pause and resume buttons
    if (pauseBtn && resumeBtn) {
        pauseBtn.addEventListener('click', () => {
            scoreTicker.style.animationPlayState = 'paused';
        });

        resumeBtn.addEventListener('click', () => {
            scoreTicker.style.animationPlayState = 'running';
        });
    }
}

// Function to initialize the testimonial slider
function initializeTestimonialSlider() {
    // Select the testimonial slider container
    const testimonialSlider = document.getElementById('testimonialSlider');

    // Data for the testimonials
    const testimonials = [
        { text: "SPU Sports has transformed my college experience!", author: "John Doe, Football Captain" },
        { text: "The facilities and coaching at SPU are world-class.", author: "Jane Smith, Basketball Player" },
        { text: "I've grown so much as an athlete and person at SPU.", author: "Mike Johnson, Track & Field" }
    ];

    // Keep track of the currently active testimonial
    let currentTestimonial = 0;

    // Function to display a specific testimonial
    function showTestimonial(index) {
        const testimonial = testimonials[index];
        testimonialSlider.innerHTML = `
            <div class="testimonial-item active">
                <p>"${testimonial.text}"</p>
                <p class="author">- ${testimonial.author}</p>
            </div>
        `;
    }

    // Function to move to the next testimonial
    function nextTestimonial() {
        currentTestimonial = (currentTestimonial + 1) % testimonials.length;
        showTestimonial(currentTestimonial);
    }

    // Display the first testimonial initially
    showTestimonial(currentTestimonial);

    // Automatically move to the next testimonial every 5 seconds
    setInterval(nextTestimonial, 5000);
}

// Function to initialize the newsletter form functionality
function initializeNewsletterForm() {
    // Select the newsletter form
    const newsletterForm = document.getElementById('newsletterForm');

    // Check if the newsletter form exists
    if (newsletterForm) {
        // Add an event listener for the 'submit' event
        newsletterForm.addEventListener('submit', (event) => {
            // Prevent the default form submission behavior
            event.preventDefault();

            // Get the email value from the form
            const email = newsletterForm.querySelector('input[type="email"]').value;

            // In a real application, you would send this email to your server
            console.log(`Subscribed email: ${email}`);

            // Display a thank you message
            alert(`Thank you for subscribing with ${email}!`);

            // Reset the form
            newsletterForm.reset();
        });
    }
}

// Function to initialize the shopping cart functionality
function initializeShoppingCart() {
    // Select the cart icon, count, popup, items container, add to cart buttons, size modal, size form, and close modal button
    const cartIcon = document.getElementById('cart-icon');
    const cartCount = document.getElementById('cart-count');
    const cartPopup = document.getElementById('cartPopup');
    const cartItemsContainer = document.getElementById('cart-items');
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    const sizeModal = document.getElementById('sizeModal');
    const sizeForm = document.getElementById('sizeForm');
    const closeModalButton = sizeModal.querySelector('.close-modal');

    // Initialize the cart as an empty array
    let cart = [];

    // Function to update the cart icon display
    function updateCartIcon() {
        // Calculate the total quantity of items in the cart
        const totalQuantity = cart.reduce((sum, item) => sum + item.quantity, 0);

        // Update the cart count display
        cartCount.textContent = totalQuantity;
    }

    // Function to toggle the cart popup visibility
    function toggleCartPopup() {
        // Toggle the display property of the cart popup
        cartPopup.style.display = cartPopup.style.display === 'block' ? 'none' : 'block';
    }

    // Function to update the cart popup display
    function updateCartPopup() {
        // Clear the cart items container
        cartItemsContainer.innerHTML = '';

        // Initialize the total price
        let totalPrice = 0;

        // Add each cart item to the cart items container
        cart.forEach((item, index) => {
            const li = document.createElement('li');
            li.innerHTML = `${item.name} ${item.size ? `(${item.size})` : ''} (Quantity: ${item.quantity}) - R${(item.price * item.quantity).toFixed(2)} <button class="remove-item-btn" data-index="${index}">×</button>`;
            cartItemsContainer.appendChild(li);

            // Add to the total price
            totalPrice += item.price * item.quantity;
        });

        // Update the total price display
        document.getElementById('cart-total').textContent = totalPrice.toFixed(2);

        // Add event listeners to remove buttons
        document.querySelectorAll('.remove-item-btn').forEach(button => {
            button.addEventListener('click', removeFromCart);
        });
    }

    // Function to remove an item from the cart
    function removeFromCart(event) {
        // Get the index of the item to remove
        const index = event.target.dataset.index;

        // Remove the item from the cart array
        cart.splice(index, 1);

        // Update the cart icon and popup
        updateCartIcon();
        updateCartPopup();
    }

    // Function to clear the cart
    function clearCart() {
        // Clear the cart array
        cart = [];

        // Update the cart icon and popup
        updateCartIcon();
        updateCartPopup();
    }

    // Function to add an item to the cart
    function addToCart(event) {
        const button = event.target;
        const card = button.closest('.card');
        const id = card.dataset.id;
        const name = card.dataset.name;
        const price = parseFloat(card.dataset.price);

        // Open the size selection modal for all items
        openSizeModal(id, name, price);
    }

    // Function to open the size selection modal
    function openSizeModal(id, name, price) {
        // Set data attributes on the modal for later use
        sizeModal.setAttribute('data-product-id', id);
        sizeModal.setAttribute('data-product-name', name);
        sizeModal.setAttribute('data-product-price', price);

        // Show the modal
        sizeModal.style.display = 'block';
    }

    // Function to add an item to the cart with size
    function addToCartWithSize(event) {
        // Prevent the default form submission behavior
        event.preventDefault();

        // Get the selected size
        const selectedSize = sizeForm.size.value;

        // Get the data attributes of the item from the modal
        const productId = sizeModal.getAttribute('data-product-id');
        const productName = sizeModal.getAttribute('data-product-name');
        const productPrice = parseFloat(sizeModal.getAttribute('data-product-price'));

        // Add the item to the cart with the selected size
        addItemToCart(productId, productName, productPrice, selectedSize);

        // Close the modal
        sizeModal.style.display = 'none';

        // Reset the form
        sizeForm.reset();
    }

    // Function to add an item to the cart (with or without size)
    function addItemToCart(id, name, price, size = null) {
        // Check if the item already exists in the cart
        const existingItem = cart.find(item => item.id === id && item.size === size);

        if (existingItem) {
            // If the item exists, increase its quantity
            existingItem.quantity++;
        } else {
            // If the item doesn't exist, add it to the cart
            cart.push({ id, name, price, quantity: 1, size });
        }

        // Update the cart icon and popup
        updateCartIcon();
        updateCartPopup();
    }

    // Add event listeners to add to cart buttons
    addToCartButtons.forEach(button => {
        button.addEventListener('click', addToCart);
    });

    // Add event listener to cart icon
    cartIcon.addEventListener('click', toggleCartPopup);

    // Add event listener to close button in cart popup
    document.querySelector('.cart-popup .close-cart').addEventListener('click', () => {
        cartPopup.style.display = 'none';
    });

    // Add event listener to clear cart button
    document.getElementById('clearCartBtn').addEventListener('click', clearCart);

    // Add event listener to checkout button
    document.getElementById('checkoutBtn').addEventListener('click', () => {
        // This is a placeholder for checkout functionality
        alert('Thank you for your purchase! This is a demo, so no actual transaction will occur.');
        clearCart();
    });

    // Add event listener to close modal button
    closeModalButton.addEventListener('click', () => {
        sizeModal.style.display = 'none';
    });

    // Add event listener to size form
    sizeForm.addEventListener('submit', addToCartWithSize);

    // Close modal if clicked outside of it
    window.addEventListener('click', (event) => {
        if (event.target === sizeModal) {
            sizeModal.style.display = 'none';
        }
    });
}